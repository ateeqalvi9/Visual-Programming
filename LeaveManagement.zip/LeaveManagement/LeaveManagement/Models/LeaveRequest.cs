﻿namespace LeaveManagement.Models
{
    public class LeaveRequest
    {
        public int Id { get; set; }
        public string? UserName { get; set; }
        public string? LeaveType { get; set; }
        public DateTime From { get; set; }
        public DateTime To { get; set; }
        public string? Status { get; set; }
    }
}
