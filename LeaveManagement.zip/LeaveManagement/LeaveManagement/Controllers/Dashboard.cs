﻿using LeaveManagement.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LeaveManagement.Controllers
{
    [Authorize]
    public class Dashboard : Controller
    {
        private readonly ApplicationDbContext _context;

        public Dashboard(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            ViewBag.TotalLeaveTypes = await _context.LeaveTypes.CountAsync();
            ViewBag.TotalRequests = await _context.LeaveRequests.CountAsync();
            ViewBag.Pending = await _context.LeaveRequests.CountAsync(x => x.Status == "Pending");

            return View();
        }
    }
}
