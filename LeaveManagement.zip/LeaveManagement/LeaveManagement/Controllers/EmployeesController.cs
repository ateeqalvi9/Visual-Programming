﻿using LeaveManagement.Data;
using LeaveManagement.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LeaveManagement.Controllers
{
    [Authorize(Roles = "Admin")]
    public class EmployeesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public EmployeesController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View(_context.Employees.ToList());
        }

        public IActionResult Create() => View();

        public ApplicationDbContext Get_context()
        {
            return _context;
        }

        [HttpPost]
        public async Task<IActionResult> CreateAsync(EmployeeModel emp, ApplicationDbContext _context)
        {
            if (ModelState.IsValid)
            {
                _context.Employees.Add(emp);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(emp);
        }

        public IActionResult Edit(int id)
        {
            return View(_context.Employees.Find(id));
        }

        [HttpPost]
        public IActionResult Edit(EmployeeModel emp)
        {
            _context.Employees.Update(emp);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult ToggleStatus(int id)
        {
            var emp = _context.Employees.Find(id);
            emp.IsActive = !emp.IsActive;
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
