﻿using LeaveManagement.Data;
using LeaveManagement.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LeaveManagement.Controllers
{
    [Authorize]
    public class LeaveController : Controller
    {
        private readonly ApplicationDbContext _context;

        public LeaveController(ApplicationDbContext context)
        {
            _context = context;
        }

        [Authorize(Roles = "Employee")]
        public IActionResult MyLeaves()
        {
            var email = User.Identity.Name;
            var emp = _context.Employees.First(e => e.Email == email);
            return View(_context.Leaves.Where(l => l.EmployeeId == emp.EmployeeId).ToList());
        }

        [Authorize(Roles = "Employee")]
        public IActionResult Apply() => View();

        [HttpPost]
        [Authorize(Roles = "Employee")]
        public IActionResult Apply(LeaveModel leave)
        {
            leave.Status = "Pending";
            _context.Leaves.Add(leave);
            _context.SaveChanges();
            return RedirectToAction("MyLeaves");
        }

        [Authorize(Roles = "Admin")]
        public IActionResult All()
        {
            return View(_context.Leaves.Include(e => e.Employee).ToList());
        }

        [Authorize(Roles = "Admin")]
        public IActionResult Approve(int id)
        {
            var leave = _context.Leaves.Find(id);
            leave.Status = "Approved";
            _context.SaveChanges();
            return RedirectToAction("All");
        }

        [Authorize(Roles = "Admin")]
        public IActionResult Reject(int id)
        {
            var leave = _context.Leaves.Find(id);
            leave.Status = "Rejected";
            _context.SaveChanges();
            return RedirectToAction("All");
        }
        public IActionResult Index()
        {
            return View();
        }
    }
}
