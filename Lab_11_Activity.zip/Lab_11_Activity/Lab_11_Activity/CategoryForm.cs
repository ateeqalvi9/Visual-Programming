﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Lab_11_Activity
{
    public partial class CategoryForm : Form
    {
        public CategoryForm()
        {
            InitializeComponent();
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                using (LibraryContext context = new LibraryContext())
                {
                    string categoryName = textBox2.Text;
                    if (context.Categories.Any(c => c.CategoryName == categoryName))
                    {
                        MessageBox.Show("Category already exists!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    context.Categories.Add(new Category
                    {
                        CategoryName = categoryName
                    });

                    context.SaveChanges();

                    MessageBox.Show("Category Added Successfully!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    textBox2.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message + "\nInner: " + ex.InnerException?.Message);
            }
        }

        private void CategoryForm_Load(object sender, EventArgs e)
        {

        }
    }
}
