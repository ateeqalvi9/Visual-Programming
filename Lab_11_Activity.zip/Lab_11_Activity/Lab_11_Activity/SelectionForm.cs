﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_11_Activity
{
    public partial class SelectionForm : Form
    {
        public SelectionForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) 
        {
            using (LibraryContext context = new LibraryContext())
            {
                var result = from b in context.Books
                             join a in context.Authors on b.AuthorId equals a.AuthorId
                             select new { b.Title, Author = a.Name };

                dataGridView1.DataSource = result.ToList();
            }
        }

        private void button2_Click(object sender, EventArgs e) 
        {
            using (LibraryContext context = new LibraryContext())
            {
                var result = from b in context.Books
                             join c in context.Categories on b.CategoryId equals c.CategoryId
                             select new { b.Title, Category = c.CategoryName };

                dataGridView1.DataSource = result.ToList();
            }
        }

        private void button3_Click(object sender, EventArgs e) 
        {
            using (LibraryContext context = new LibraryContext())
            {
                var result = from a in context.Authors
                             join b in context.Books on a.AuthorId equals b.AuthorId into bookGroup
                             select new { a.Name, BookCount = bookGroup.Count() };

                dataGridView1.DataSource = result.ToList();
            }
        }

        private void button4_Click(object sender, EventArgs e) 
        {
            using (LibraryContext context = new LibraryContext())
            {
                var result = from a in context.Authors
                             join b in context.Books on a.AuthorId equals b.AuthorId into bookGroup
                             from bg in bookGroup.DefaultIfEmpty()
                             select new
                             {
                                 a.Name,
                                 BookName = bg == null ? "No Book" : bg.Title
                             };

                dataGridView1.DataSource = result.ToList();
            }
        }
    }
}
