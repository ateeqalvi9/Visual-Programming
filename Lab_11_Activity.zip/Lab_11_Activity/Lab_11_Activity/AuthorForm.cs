﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Lab_11_Activity
{
    public partial class AuthorForm : Form
    {
        public AuthorForm()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                using (LibraryContext context = new LibraryContext())
                {
                    int authorId = Convert.ToInt32(textBox1.Text);
                    string name = textBox2.Text;
                    if (context.Authors.Any(a => a.AuthorId == authorId))
                    {
                        MessageBox.Show("Author ID already exists!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    context.Authors.Add(new Author
                    {
                        AuthorId = authorId,
                        Name = name
                    });
                    context.SaveChanges();

                    MessageBox.Show("Author Added Successfully!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    textBox1.Clear();
                    textBox2.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message + "\nInner: " + ex.InnerException?.Message);
            }

        }

    }
}
