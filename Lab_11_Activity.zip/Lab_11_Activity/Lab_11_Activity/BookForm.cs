﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_11_Activity
{
    public partial class BookForm : Form
    {
        public BookForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (LibraryContext context = new LibraryContext())
                {
                    int bookId = Convert.ToInt32(textBox1.Text);
                    string title = textBox2.Text;
                    int authorId = Convert.ToInt32(textBox3.Text);
                    int categoryId = Convert.ToInt32(textBox4.Text);
                    if (context.Books.Any(b => b.BookId == bookId))
                    {
                        MessageBox.Show("Book ID already exists!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    if (!context.Authors.Any(a => a.AuthorId == authorId) ||
                        !context.Categories.Any(c => c.CategoryId == categoryId))
                    {
                        MessageBox.Show("Invalid Author or Category ID!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    context.Books.Add(new Book
                    {
                        BookId = bookId,
                        Title = title,
                        AuthorId = authorId,
                        CategoryId = categoryId
                    }
                    );
                    context.SaveChanges();
                    MessageBox.Show("Data Inserted Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    textBox4.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message + "\nInner: " + ex.InnerException?.Message);
            }
        }

    }
}
