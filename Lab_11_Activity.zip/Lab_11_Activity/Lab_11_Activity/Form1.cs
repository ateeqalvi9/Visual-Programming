namespace Lab_11_Activity
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void authorsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AuthorForm author = new AuthorForm();
            author.Show();
        }

        private void categoriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CategoryForm categories = new CategoryForm();
            categories.Show();
        }

        private void booksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BookForm book = new BookForm();
            book.Show();
        }

        private void reportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SelectionForm joinQueries = new SelectionForm();
            joinQueries.Show();
        }
    }
}
