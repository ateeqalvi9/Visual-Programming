﻿using System.ComponentModel.DataAnnotations;

namespace Student_CRUD_API.Models
{
    public class StudentModel
    {
        [Key]
        [Required]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string Address { get; set; }
    }
}
