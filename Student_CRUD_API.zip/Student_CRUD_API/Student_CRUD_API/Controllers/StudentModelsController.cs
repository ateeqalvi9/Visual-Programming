﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Student_CRUD_API.Data;
using Student_CRUD_API.Models;

namespace Student_CRUD_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentModelsController : Controller
    {
        private readonly ApiDbContext _context;
        public StudentModelsController(ApiDbContext context)
        {
            _context = context;
        }

        // GET: api/StudentModels
        [HttpGet]
        public async Task<ActionResult<IEnumerable<StudentModel>>> GetStudentModel()
        {
            return await _context.StudentModel.ToListAsync();
        }

        // GET: api/StudentModels/5
        [HttpGet("{id}")]
        public async Task<ActionResult<StudentModel>> GetStudentModel(int id)
        {
            var studentModel = await _context.StudentModel.FindAsync(id);

            if (studentModel == null)
                return NotFound();

            return studentModel;
        }

        // POST: api/StudentModels
        [HttpPost]
        public async Task<ActionResult<StudentModel>> PostStudentModel(StudentModel studentModel)
        {
            _context.StudentModel.Add(studentModel);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetStudentModel", new { id = studentModel.Id }, studentModel);
        }

        // PUT: api/StudentModels/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutStudentModel(int id, StudentModel studentModel)
        {
            if (id != studentModel.Id)
                return BadRequest();

            _context.Entry(studentModel).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/StudentModels/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteStudentModel(int id)
        {
            var studentModel = await _context.StudentModel.FindAsync(id);

            if (studentModel == null)
                return NotFound();

            _context.StudentModel.Remove(studentModel);
            await _context.SaveChangesAsync();

            return NoContent();
        }
        public IActionResult Index()
        {
            return View();
        }
    }
}
