﻿using Microsoft.EntityFrameworkCore;
using Student_CRUD_API.Models;

namespace Student_CRUD_API.Data
{
    public class ApiDbContext : DbContext
    {
        public ApiDbContext(DbContextOptions<ApiDbContext> options)
            : base(options)
        {
        }

        public DbSet<StudentModel> StudentModel { get; set; }
    }
}
