﻿using Microsoft.EntityFrameworkCore;
using EmployeeManagementMVC.Models;

namespace EmployeeManagementMVC.Data
{
    public class EmployeeDbContext : DbContext
    {
        public EmployeeDbContext(DbContextOptions<EmployeeDbContext> options)
            : base(options) { }

        public DbSet<Employee> Employees { get; set; }
    }
}