﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class Task1 : Form
    {
        public Task1()
        {
            InitializeComponent();
            this.AutoSize = true;
            this.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void btnShowText_Click(object sender, EventArgs e)
        {
            string userText = txtInput.Text;
            lblDisplay.Text = userText;
            lblDisplay.ForeColor = System.Drawing.Color.DarkRed;
        }
    }
}
