﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class LabTask1 : Form
    {
        public LabTask1()
        {
            InitializeComponent();
            cmbCountry.AutoCompleteMode = AutoCompleteMode.Suggest;
            cmbCountry.AutoCompleteSource = AutoCompleteSource.ListItems;
            cmbCountry.SelectedIndex = 0;
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            if (string.IsNullOrEmpty(lblName.Text))
            {
                MessageBox.Show("Please enter your name", "Input Required", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            sb.Append($"Name: {Name} ");
            string gender = " ";
            if (rdoMale.Checked)
            {
                gender = "Male";
            }
            else if (rdoFemale.Checked)
            {
                gender = "Female";
            }
            else
            {
                MessageBox.Show("Please select your gender.", "Input Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            sb.Append($"Gender: {gender} ");
            if (chkLanguages.CheckedItems.Count < 0)
            {
                MessageBox.Show("Please select at least one language.", "Input Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            sb.Append($"Language: ");
            foreach( string s in chkLanguages.CheckedItems)
            {
                sb.Append(s.ToString() + " ");
            }
            sb.AppendLine();
            int age = (int)numAge.Value;
            sb.Append($"Age: {age}");
            if (cmbCountry.SelectedItem == null)
            {
                MessageBox.Show("Please select a country.", "Input Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            sb.Append($"Country: {cmbCountry.SelectedItem}");
            MessageBox.Show(sb.ToString(), "Registration Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
