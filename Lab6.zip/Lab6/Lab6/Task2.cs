﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class Task2 : Form
    {
        public Task2()
        {
            InitializeComponent();
        }
        
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string languages = "";
            if (chkCPlus.Checked) languages += "C++ ";
            if (chkPython.Checked) languages += "Python ";
            if (languages == "") languages = "None";

            string gender = rdoMale.Checked ? "Male" :
                            rdoFemale.Checked ? "Female" :
                            "Not Selected";

            MessageBox.Show(
                $"Languages: {languages}\nGender: {gender}",
                "Your Selection",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );
        }
    }
}
