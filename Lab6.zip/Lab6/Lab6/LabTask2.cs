﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class LabTask2 : Form
    {
        public LabTask2()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (lstTasks.SelectedItems.Count > 0)
            {
                lstTasks.Items.Clear();
            }
            else
            {
                MessageBox.Show("List box is empty!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string tasks = txtTask.Text.Trim();
            if (!string.IsNullOrEmpty(tasks))
            {
                lstTasks.Items.Add(tasks);
                txtTask.Clear();
                txtTask.Focus();
            }
            else
            {
                MessageBox.Show("Please enter a task before adding!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (lstTasks.SelectedIndex != -1)
            {
                lstTasks.Items.RemoveAt(lstTasks.SelectedIndex);
            }
            else
            {
                MessageBox.Show("Please select a task to remove!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
