﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class Task5 : Form
    {
        public Task5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StringBuilder selections = new StringBuilder();
            selections.AppendLine("Your Interests:");
            foreach (Control control in groupBoxOptions.Controls)
            {
                if (control is CheckBox cb && cb.Checked)
                    selections.AppendLine("- " + cb.Text);
            }
            selections.AppendLine("\nGender:");
            foreach (Control control in panelGender.Controls)
            {
                if (control is RadioButton rb && rb.Checked)
                    selections.AppendLine("- " + rb.Text);
            }
            lblResult.Text = selections.ToString();
        }
    }
}
