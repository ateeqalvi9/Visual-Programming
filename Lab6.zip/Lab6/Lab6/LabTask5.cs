﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class LabTask5 : Form
    {
        public LabTask5()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            decimal num1 = numInput1.Value;
            decimal num2 = numInput2.Value;
            decimal result = num1 + num2;
            lblResult.Text = $"Result: {result}";
        }

        private void btnSubtract_Click(object sender, EventArgs e)
        {
            decimal num1 = numInput1.Value;
            decimal num2 = numInput2.Value;
            decimal result = num1 - num2;
            lblResult.Text = $"Result: {result}";
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            decimal num1 = numInput1.Value;
            decimal num2 = numInput2.Value;
            decimal result = num1 * num2;
            lblResult.Text = $"Result: {result}";
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            decimal num1 = numInput1.Value;
            decimal num2 = numInput2.Value;

            if (num2 == 0)
            {
                MessageBox.Show("Cannot divide by zero!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            decimal result = num1 / num2;
            lblResult.Text = $"Result: {Math.Round(result, 2)}";
        }
    }
}
