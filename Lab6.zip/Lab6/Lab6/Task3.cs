﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class Task3 : Form
    {
        public Task3()
        {
            InitializeComponent();
        }

        private void btnShowSelected_Click(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            if (listBox1.SelectedItem != null)
            {
                sb.AppendLine("ListBox Selected Item: " + listBox1.SelectedItem.ToString());
            }
            else
            {
                sb.AppendLine("ListBox Selected Item: None");
            }
            sb.AppendLine("CheckedListBox Selected Items:");
            if (checkedListBox1.CheckedItems.Count > 0)
            {
                foreach (var item in checkedListBox1.CheckedItems)
                {
                    sb.AppendLine("- " + item.ToString());
                }
            }
            else
            {
                sb.AppendLine("None");
            }
            MessageBox.Show(sb.ToString(), "Selected Items");
            lblResult.Text = sb.ToString();
        }
    }
}
