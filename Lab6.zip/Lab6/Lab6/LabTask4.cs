﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class LabTask4 : Form
    {
        public LabTask4()
        {
            InitializeComponent();
            cmbRoomType.Items.AddRange(new string[]
            {
                "Single Room",
                "Double Room",
                "Deluxe Room",
                "Suite"
            });
            clbServices.Items.AddRange(new string[]
            {
                "Breakfast",
                "Wi-Fi",
                "Airport Pickup",
                "Gym Access",
                "Swimming Pool"
            });
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            DateTime checkInDate = dtpCheckIn.Value;
            int guests = (int)numGuests.Value;
            string roomType = cmbRoomType.SelectedItem != null ? cmbRoomType.SelectedItem.ToString() : "Not selected";  
            string services = clbServices.CheckedItems.Count > 0
                ? string.Join(", ", clbServices.CheckedItems.Cast<string>())
                : "No extra services";
            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Please enter your name!", "Missing Info", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (cmbRoomType.SelectedItem == null)
            {
                MessageBox.Show("Please select a room type!", "Missing Info", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            lblBookingInfo.Text =
                $"Booking Details:\n\n" +
                $"Name: {name}\n" +
                $"Check-in Date: {checkInDate.ToShortDateString()}\n" +
                $"Number of Guests: {guests}\n" +
                $"Room Type: {roomType}\n" +
                $"Services: {services}";
        }
    }
}
