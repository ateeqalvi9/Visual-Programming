﻿namespace Lab6
{
    partial class LabTask4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblName = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblGuests = new System.Windows.Forms.Label();
            this.lblRoom = new System.Windows.Forms.Label();
            this.lblServices = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.dtpCheckIn = new System.Windows.Forms.DateTimePicker();
            this.numGuests = new System.Windows.Forms.NumericUpDown();
            this.cmbRoomType = new System.Windows.Forms.ComboBox();
            this.clbServices = new System.Windows.Forms.CheckedListBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.lblBookingInfo = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numGuests)).BeginInit();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(27, 27);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(35, 13);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Name";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(30, 74);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(75, 13);
            this.lblDate.TabIndex = 1;
            this.lblDate.Text = "Check-in Date";
            // 
            // lblGuests
            // 
            this.lblGuests.AutoSize = true;
            this.lblGuests.Location = new System.Drawing.Point(30, 127);
            this.lblGuests.Name = "lblGuests";
            this.lblGuests.Size = new System.Drawing.Size(92, 13);
            this.lblGuests.TabIndex = 2;
            this.lblGuests.Text = "Number of Guests";
            // 
            // lblRoom
            // 
            this.lblRoom.AutoSize = true;
            this.lblRoom.Location = new System.Drawing.Point(30, 177);
            this.lblRoom.Name = "lblRoom";
            this.lblRoom.Size = new System.Drawing.Size(62, 13);
            this.lblRoom.TabIndex = 3;
            this.lblRoom.Text = "Room Type";
            // 
            // lblServices
            // 
            this.lblServices.AutoSize = true;
            this.lblServices.Location = new System.Drawing.Point(30, 221);
            this.lblServices.Name = "lblServices";
            this.lblServices.Size = new System.Drawing.Size(94, 13);
            this.lblServices.TabIndex = 4;
            this.lblServices.Text = "Services Required";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(126, 27);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 20);
            this.txtName.TabIndex = 5;
            // 
            // dtpCheckIn
            // 
            this.dtpCheckIn.Location = new System.Drawing.Point(126, 74);
            this.dtpCheckIn.Name = "dtpCheckIn";
            this.dtpCheckIn.Size = new System.Drawing.Size(200, 20);
            this.dtpCheckIn.TabIndex = 6;
            // 
            // numGuests
            // 
            this.numGuests.Location = new System.Drawing.Point(126, 120);
            this.numGuests.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numGuests.Name = "numGuests";
            this.numGuests.Size = new System.Drawing.Size(120, 20);
            this.numGuests.TabIndex = 7;
            this.numGuests.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // cmbRoomType
            // 
            this.cmbRoomType.FormattingEnabled = true;
            this.cmbRoomType.Location = new System.Drawing.Point(126, 169);
            this.cmbRoomType.Name = "cmbRoomType";
            this.cmbRoomType.Size = new System.Drawing.Size(121, 21);
            this.cmbRoomType.TabIndex = 8;
            // 
            // clbServices
            // 
            this.clbServices.FormattingEnabled = true;
            this.clbServices.Location = new System.Drawing.Point(126, 221);
            this.clbServices.Name = "clbServices";
            this.clbServices.Size = new System.Drawing.Size(120, 94);
            this.clbServices.TabIndex = 9;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(341, 313);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 23);
            this.btnSubmit.TabIndex = 10;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // lblBookingInfo
            // 
            this.lblBookingInfo.AutoSize = true;
            this.lblBookingInfo.Location = new System.Drawing.Point(123, 335);
            this.lblBookingInfo.Name = "lblBookingInfo";
            this.lblBookingInfo.Size = new System.Drawing.Size(37, 13);
            this.lblBookingInfo.TabIndex = 11;
            this.lblBookingInfo.Text = "Result";
            // 
            // LabTask4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblBookingInfo);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.clbServices);
            this.Controls.Add(this.cmbRoomType);
            this.Controls.Add(this.numGuests);
            this.Controls.Add(this.dtpCheckIn);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblServices);
            this.Controls.Add(this.lblRoom);
            this.Controls.Add(this.lblGuests);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.lblName);
            this.Name = "LabTask4";
            this.Text = "LabTask4";
            ((System.ComponentModel.ISupportInitialize)(this.numGuests)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblGuests;
        private System.Windows.Forms.Label lblRoom;
        private System.Windows.Forms.Label lblServices;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.DateTimePicker dtpCheckIn;
        private System.Windows.Forms.NumericUpDown numGuests;
        private System.Windows.Forms.ComboBox cmbRoomType;
        private System.Windows.Forms.CheckedListBox clbServices;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Label lblBookingInfo;
    }
}