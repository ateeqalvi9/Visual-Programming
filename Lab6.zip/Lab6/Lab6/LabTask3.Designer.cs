﻿namespace Lab6
{
    partial class LabTask3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.chkQ1CSharp = new System.Windows.Forms.CheckBox();
            this.chkQ1Python = new System.Windows.Forms.CheckBox();
            this.chkQ1HTML = new System.Windows.Forms.CheckBox();
            this.chkQ1CSS = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.rdoQ2Earth = new System.Windows.Forms.RadioButton();
            this.rdoQ2Mars = new System.Windows.Forms.RadioButton();
            this.rdoQ2Jupiter = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbQ3 = new System.Windows.Forms.ComboBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(263, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "1. Which of the following are programming languages?";
            // 
            // chkQ1CSharp
            // 
            this.chkQ1CSharp.AutoSize = true;
            this.chkQ1CSharp.Location = new System.Drawing.Point(26, 60);
            this.chkQ1CSharp.Name = "chkQ1CSharp";
            this.chkQ1CSharp.Size = new System.Drawing.Size(40, 17);
            this.chkQ1CSharp.TabIndex = 1;
            this.chkQ1CSharp.Text = "C#";
            this.chkQ1CSharp.UseVisualStyleBackColor = true;
            // 
            // chkQ1Python
            // 
            this.chkQ1Python.AutoSize = true;
            this.chkQ1Python.Location = new System.Drawing.Point(26, 84);
            this.chkQ1Python.Name = "chkQ1Python";
            this.chkQ1Python.Size = new System.Drawing.Size(59, 17);
            this.chkQ1Python.TabIndex = 2;
            this.chkQ1Python.Text = "Python";
            this.chkQ1Python.UseVisualStyleBackColor = true;
            // 
            // chkQ1HTML
            // 
            this.chkQ1HTML.AutoSize = true;
            this.chkQ1HTML.Location = new System.Drawing.Point(26, 108);
            this.chkQ1HTML.Name = "chkQ1HTML";
            this.chkQ1HTML.Size = new System.Drawing.Size(56, 17);
            this.chkQ1HTML.TabIndex = 3;
            this.chkQ1HTML.Text = "HTML";
            this.chkQ1HTML.UseVisualStyleBackColor = true;
            // 
            // chkQ1CSS
            // 
            this.chkQ1CSS.AutoSize = true;
            this.chkQ1CSS.Location = new System.Drawing.Point(26, 132);
            this.chkQ1CSS.Name = "chkQ1CSS";
            this.chkQ1CSS.Size = new System.Drawing.Size(47, 17);
            this.chkQ1CSS.TabIndex = 4;
            this.chkQ1CSS.Text = "CSS";
            this.chkQ1CSS.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(323, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(221, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "2. Which planet is known as the Red Planet?";
            // 
            // rdoQ2Earth
            // 
            this.rdoQ2Earth.AutoSize = true;
            this.rdoQ2Earth.Location = new System.Drawing.Point(315, 60);
            this.rdoQ2Earth.Name = "rdoQ2Earth";
            this.rdoQ2Earth.Size = new System.Drawing.Size(50, 17);
            this.rdoQ2Earth.TabIndex = 6;
            this.rdoQ2Earth.TabStop = true;
            this.rdoQ2Earth.Text = "Earth";
            this.rdoQ2Earth.UseVisualStyleBackColor = true;
            // 
            // rdoQ2Mars
            // 
            this.rdoQ2Mars.AutoSize = true;
            this.rdoQ2Mars.Location = new System.Drawing.Point(315, 84);
            this.rdoQ2Mars.Name = "rdoQ2Mars";
            this.rdoQ2Mars.Size = new System.Drawing.Size(48, 17);
            this.rdoQ2Mars.TabIndex = 7;
            this.rdoQ2Mars.TabStop = true;
            this.rdoQ2Mars.Text = "Mars";
            this.rdoQ2Mars.UseVisualStyleBackColor = true;
            // 
            // rdoQ2Jupiter
            // 
            this.rdoQ2Jupiter.AutoSize = true;
            this.rdoQ2Jupiter.Location = new System.Drawing.Point(315, 108);
            this.rdoQ2Jupiter.Name = "rdoQ2Jupiter";
            this.rdoQ2Jupiter.Size = new System.Drawing.Size(56, 17);
            this.rdoQ2Jupiter.TabIndex = 8;
            this.rdoQ2Jupiter.TabStop = true;
            this.rdoQ2Jupiter.Text = "Jupiter";
            this.rdoQ2Jupiter.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(26, 183);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(161, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "3. What is the capital of France?";
            // 
            // cmbQ3
            // 
            this.cmbQ3.FormattingEnabled = true;
            this.cmbQ3.Items.AddRange(new object[] {
            "London",
            "Paris",
            "Berlin",
            "Rome"});
            this.cmbQ3.Location = new System.Drawing.Point(26, 220);
            this.cmbQ3.Name = "cmbQ3";
            this.cmbQ3.Size = new System.Drawing.Size(121, 21);
            this.cmbQ3.TabIndex = 10;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(223, 280);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 23);
            this.btnSubmit.TabIndex = 11;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // LabTask3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.cmbQ3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.rdoQ2Jupiter);
            this.Controls.Add(this.rdoQ2Mars);
            this.Controls.Add(this.rdoQ2Earth);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.chkQ1CSS);
            this.Controls.Add(this.chkQ1HTML);
            this.Controls.Add(this.chkQ1Python);
            this.Controls.Add(this.chkQ1CSharp);
            this.Controls.Add(this.label1);
            this.Name = "LabTask3";
            this.Text = "LabTask3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chkQ1CSharp;
        private System.Windows.Forms.CheckBox chkQ1Python;
        private System.Windows.Forms.CheckBox chkQ1HTML;
        private System.Windows.Forms.CheckBox chkQ1CSS;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton rdoQ2Earth;
        private System.Windows.Forms.RadioButton rdoQ2Mars;
        private System.Windows.Forms.RadioButton rdoQ2Jupiter;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbQ3;
        private System.Windows.Forms.Button btnSubmit;
    }
}