﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void task1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Task1 task1 = new Task1();
            task1.Show();
        }

        private void task2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Task2 task2 = new Task2();
            task2.Show();
        }

        private void task3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Task3 task3 = new Task3();
            task3.Show();
        }

        private void task4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Task4 task4 = new Task4();
            task4.Show();
        }

        private void task5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Task5 task5 = new Task5();
            task5.Show();
        }

        private void task6ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Task6 task6 = new Task6();
            task6.Show();
        }

        private void task1ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LabTask1 task1 = new LabTask1();
            task1.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void task2ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LabTask2 task2 = new LabTask2();
            task2.Show();
        }

        private void task3ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LabTask3 task3 = new LabTask3();
            task3.Show();
        }

        private void task4ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LabTask4 task4 = new LabTask4();
            task4.Show();
        }

        private void task5ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LabTask5 task5 = new LabTask5();
            task5.Show();
        }
    }
}
