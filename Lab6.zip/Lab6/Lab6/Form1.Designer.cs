﻿namespace Lab6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.lab6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.task1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.task2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.task3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.task4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.task5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.task6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.doItYourSelfToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.task1ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.task2ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.task3ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.task4ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.task5ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lab6ToolStripMenuItem,
            this.doItYourSelfToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // lab6ToolStripMenuItem
            // 
            this.lab6ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.task1ToolStripMenuItem,
            this.task2ToolStripMenuItem,
            this.task3ToolStripMenuItem,
            this.task4ToolStripMenuItem,
            this.task5ToolStripMenuItem,
            this.task6ToolStripMenuItem});
            this.lab6ToolStripMenuItem.Name = "lab6ToolStripMenuItem";
            this.lab6ToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.lab6ToolStripMenuItem.Text = "Lab6";
            // 
            // task1ToolStripMenuItem
            // 
            this.task1ToolStripMenuItem.Name = "task1ToolStripMenuItem";
            this.task1ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.task1ToolStripMenuItem.Text = "Task1";
            this.task1ToolStripMenuItem.Click += new System.EventHandler(this.task1ToolStripMenuItem_Click);
            // 
            // task2ToolStripMenuItem
            // 
            this.task2ToolStripMenuItem.Name = "task2ToolStripMenuItem";
            this.task2ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.task2ToolStripMenuItem.Text = "Task2";
            this.task2ToolStripMenuItem.Click += new System.EventHandler(this.task2ToolStripMenuItem_Click);
            // 
            // task3ToolStripMenuItem
            // 
            this.task3ToolStripMenuItem.Name = "task3ToolStripMenuItem";
            this.task3ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.task3ToolStripMenuItem.Text = "Task3";
            this.task3ToolStripMenuItem.Click += new System.EventHandler(this.task3ToolStripMenuItem_Click);
            // 
            // task4ToolStripMenuItem
            // 
            this.task4ToolStripMenuItem.Name = "task4ToolStripMenuItem";
            this.task4ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.task4ToolStripMenuItem.Text = "Task4";
            this.task4ToolStripMenuItem.Click += new System.EventHandler(this.task4ToolStripMenuItem_Click);
            // 
            // task5ToolStripMenuItem
            // 
            this.task5ToolStripMenuItem.Name = "task5ToolStripMenuItem";
            this.task5ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.task5ToolStripMenuItem.Text = "Task5";
            this.task5ToolStripMenuItem.Click += new System.EventHandler(this.task5ToolStripMenuItem_Click);
            // 
            // task6ToolStripMenuItem
            // 
            this.task6ToolStripMenuItem.Name = "task6ToolStripMenuItem";
            this.task6ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.task6ToolStripMenuItem.Text = "Task6";
            this.task6ToolStripMenuItem.Click += new System.EventHandler(this.task6ToolStripMenuItem_Click);
            // 
            // doItYourSelfToolStripMenuItem
            // 
            this.doItYourSelfToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.task1ToolStripMenuItem1,
            this.task2ToolStripMenuItem1,
            this.task3ToolStripMenuItem1,
            this.task4ToolStripMenuItem1,
            this.task5ToolStripMenuItem1});
            this.doItYourSelfToolStripMenuItem.Name = "doItYourSelfToolStripMenuItem";
            this.doItYourSelfToolStripMenuItem.Size = new System.Drawing.Size(93, 20);
            this.doItYourSelfToolStripMenuItem.Text = "Do It Your Self";
            // 
            // task1ToolStripMenuItem1
            // 
            this.task1ToolStripMenuItem1.Name = "task1ToolStripMenuItem1";
            this.task1ToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.task1ToolStripMenuItem1.Text = "Task1";
            this.task1ToolStripMenuItem1.Click += new System.EventHandler(this.task1ToolStripMenuItem1_Click);
            // 
            // task2ToolStripMenuItem1
            // 
            this.task2ToolStripMenuItem1.Name = "task2ToolStripMenuItem1";
            this.task2ToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.task2ToolStripMenuItem1.Text = "Task2";
            this.task2ToolStripMenuItem1.Click += new System.EventHandler(this.task2ToolStripMenuItem1_Click);
            // 
            // task3ToolStripMenuItem1
            // 
            this.task3ToolStripMenuItem1.Name = "task3ToolStripMenuItem1";
            this.task3ToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.task3ToolStripMenuItem1.Text = "Task3";
            this.task3ToolStripMenuItem1.Click += new System.EventHandler(this.task3ToolStripMenuItem1_Click);
            // 
            // task4ToolStripMenuItem1
            // 
            this.task4ToolStripMenuItem1.Name = "task4ToolStripMenuItem1";
            this.task4ToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.task4ToolStripMenuItem1.Text = "Task4";
            this.task4ToolStripMenuItem1.Click += new System.EventHandler(this.task4ToolStripMenuItem1_Click);
            // 
            // task5ToolStripMenuItem1
            // 
            this.task5ToolStripMenuItem1.Name = "task5ToolStripMenuItem1";
            this.task5ToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.task5ToolStripMenuItem1.Text = "Task5";
            this.task5ToolStripMenuItem1.Click += new System.EventHandler(this.task5ToolStripMenuItem1_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem lab6ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem task1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem task2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem task3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem task4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem task5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem task6ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem doItYourSelfToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem task1ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem task2ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem task3ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem task4ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem task5ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    }
}

