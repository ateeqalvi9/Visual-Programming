﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class LabTask3 : Form
    {
        public LabTask3()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            int score = 0;
            if (chkQ1CSharp.Checked && chkQ1Python.Checked &&
                !chkQ1HTML.Checked && !chkQ1CSS.Checked)
            {
                score++;
            }
            if (rdoQ2Mars.Checked)
            {
                score++;
            }
            if (cmbQ3.SelectedItem != null && cmbQ3.SelectedItem.ToString() == "Paris")
            {
                score++;
            }
            MessageBox.Show($"Your total score is: {score} / 3",
                "Quiz Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
