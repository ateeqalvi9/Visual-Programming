﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class Task4 : Form
    {
        public Task4()
        {
            InitializeComponent();
            comboBoxCountry.Items.AddRange(new string[]
            {
                "Pakistan",
                "USA",
                "Canada",
                "Japan",
                "Germany"
            });
            comboBoxCountry.AutoCompleteMode = AutoCompleteMode.Suggest;
            comboBoxCountry.AutoCompleteSource = AutoCompleteSource.ListItems;
            comboBoxCountry.SelectedIndex = 0;
        }
        private void btnShowInfo_Click(object sender, EventArgs e)
        {
            string country = comboBoxCountry.SelectedItem.ToString();
            int age = (int)numericUpDownAge.Value;
            lblResult.Text = $"You are {age} years old and live in {country}.";
        }
    }
}
