﻿using AirTicketBookingAPI.Model;
using Microsoft.EntityFrameworkCore;

namespace AirTicketBookingAPI.Data
{
    public class AirTicketDbContext : DbContext
    {
        public AirTicketDbContext(DbContextOptions<AirTicketDbContext> options)
            : base(options)
        {
        }

        public DbSet<Flight> Flights { get; set; }
    }
}
