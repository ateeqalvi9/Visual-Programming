﻿using System.ComponentModel.DataAnnotations;

namespace AirTicketBookingAPI.Model
{
    public class Flight
    {
        [Key]
        public int FlightId { get; set; }

        [Required]
        [StringLength(10)]
        public string FlightNumber { get; set; }

        [Required]
        [StringLength(50)]
        public string Airline { get; set; }

        [Required]
        [StringLength(50)]
        public string FromCity { get; set; }

        [Required]
        [StringLength(50)]
        public string ToCity { get; set; }

        [Required]
        public DateTime DepartureTime { get; set; }

        [Required]
        public DateTime ArrivalTime { get; set; }

        [Required]
        [Range(1, double.MaxValue, ErrorMessage = "Ticket price must be greater than 0")]
        public decimal TicketPrice { get; set; }

        [Required]
        [Range(0, int.MaxValue, ErrorMessage = "Available seats cannot be negative")]
        public int AvailableSeats { get; set; }
    }
}
