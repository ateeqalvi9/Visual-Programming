namespace EntityFrameworkCore_Students
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            Student student = new Student
            {
                Name = txtName.Text
            };

            StudentContext db = new StudentContext();
            db.Students.Add(student);
            db.SaveChanges();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Student student = new Student
            {
                Name = txtName.Text
            };

            StudentContext db = new StudentContext();
            db.Students.Update(student);
            db.SaveChanges();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;

            using (StudentContext db = new StudentContext())
            {
                var student = db.Students.FirstOrDefault(s => s.Name == name);

                if (student != null)
                {
                    db.Students.Remove(student);
                    db.SaveChanges();
                    MessageBox.Show("Record deleted successfully!");
                }
                else
                {
                    MessageBox.Show("Student not found!");
                }
            }
        }


        private void btnSearch_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;

            using (StudentContext db = new StudentContext())
            {
                var found = db.Students.FirstOrDefault(s => s.Name == name);

                List<Student> students = new List<Student>();

                if (found != null)
                {
                    students.Add(found);
                }
                else
                {
                    MessageBox.Show("Record not found!");
                }

                dataGridView1.DataSource = students;
            }
        }

        private void btnViewAll_Click(object sender, EventArgs e)
        {
            StudentContext db = new StudentContext();
            dataGridView1.DataSource = db.Students.ToList();
        }
    }
}
