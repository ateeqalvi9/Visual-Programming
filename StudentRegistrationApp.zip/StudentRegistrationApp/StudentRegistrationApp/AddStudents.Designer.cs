﻿namespace StudentRegistrationApp
{
    partial class AddStudents
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtName = new TextBox();
            txtFatherName = new TextBox();
            txtCNIC = new TextBox();
            txtAddress = new TextBox();
            cmbGender = new ComboBox();
            dtpDOB = new DateTimePicker();
            cmbDegree = new ComboBox();
            txtMatric = new TextBox();
            txtInter = new TextBox();
            btnAddStudent = new Button();
            SuspendLayout();
            // 
            // txtName
            // 
            txtName.Location = new Point(44, 20);
            txtName.Name = "txtName";
            txtName.PlaceholderText = "Name";
            txtName.Size = new Size(100, 23);
            txtName.TabIndex = 0;
            // 
            // txtFatherName
            // 
            txtFatherName.Location = new Point(174, 20);
            txtFatherName.Name = "txtFatherName";
            txtFatherName.PlaceholderText = "FatherName";
            txtFatherName.Size = new Size(100, 23);
            txtFatherName.TabIndex = 1;
            // 
            // txtCNIC
            // 
            txtCNIC.Location = new Point(300, 20);
            txtCNIC.Name = "txtCNIC";
            txtCNIC.PlaceholderText = "CNIC";
            txtCNIC.Size = new Size(100, 23);
            txtCNIC.TabIndex = 2;
            // 
            // txtAddress
            // 
            txtAddress.Location = new Point(44, 68);
            txtAddress.Name = "txtAddress";
            txtAddress.PlaceholderText = "Address";
            txtAddress.Size = new Size(100, 23);
            txtAddress.TabIndex = 3;
            // 
            // cmbGender
            // 
            cmbGender.FormattingEnabled = true;
            cmbGender.Location = new Point(174, 68);
            cmbGender.Name = "cmbGender";
            cmbGender.Size = new Size(121, 23);
            cmbGender.TabIndex = 4;
            // 
            // dtpDOB
            // 
            dtpDOB.Location = new Point(327, 68);
            dtpDOB.Name = "dtpDOB";
            dtpDOB.Size = new Size(200, 23);
            dtpDOB.TabIndex = 5;
            // 
            // cmbDegree
            // 
            cmbDegree.FormattingEnabled = true;
            cmbDegree.Location = new Point(44, 129);
            cmbDegree.Name = "cmbDegree";
            cmbDegree.Size = new Size(121, 23);
            cmbDegree.TabIndex = 6;
            // 
            // txtMatric
            // 
            txtMatric.Location = new Point(195, 129);
            txtMatric.Name = "txtMatric";
            txtMatric.PlaceholderText = "Matric Grade";
            txtMatric.Size = new Size(100, 23);
            txtMatric.TabIndex = 7;
            // 
            // txtInter
            // 
            txtInter.Location = new Point(327, 129);
            txtInter.Name = "txtInter";
            txtInter.PlaceholderText = "Intermediate Grade";
            txtInter.Size = new Size(128, 23);
            txtInter.TabIndex = 8;
            // 
            // btnAddStudent
            // 
            btnAddStudent.Location = new Point(218, 217);
            btnAddStudent.Name = "btnAddStudent";
            btnAddStudent.Size = new Size(75, 23);
            btnAddStudent.TabIndex = 9;
            btnAddStudent.Text = "Add";
            btnAddStudent.UseVisualStyleBackColor = true;
            btnAddStudent.Click += btnAddStudent_Click;
            // 
            // AddStudents
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnAddStudent);
            Controls.Add(txtInter);
            Controls.Add(txtMatric);
            Controls.Add(cmbDegree);
            Controls.Add(dtpDOB);
            Controls.Add(cmbGender);
            Controls.Add(txtAddress);
            Controls.Add(txtCNIC);
            Controls.Add(txtFatherName);
            Controls.Add(txtName);
            Name = "AddStudents";
            Text = "AddStudents";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtName;
        private TextBox txtFatherName;
        private TextBox txtCNIC;
        private TextBox txtAddress;
        private ComboBox cmbGender;
        private DateTimePicker dtpDOB;
        private ComboBox cmbDegree;
        private TextBox txtMatric;
        private TextBox txtInter;
        private Button btnAddStudent;
    }
}