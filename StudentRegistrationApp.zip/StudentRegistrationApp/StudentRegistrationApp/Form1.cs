namespace StudentRegistrationApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void addStudentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddStudents add = new AddStudents();
            add.Show();
        }

        private void viewStudentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewStudents viewStudents = new ViewStudents();
            viewStudents.Show();
        }

        private void updateStudentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateStudents update = new UpdateStudents();
            update.Show();
        }

        private void deleteStudentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteStudents delete = new DeleteStudents();
            delete.Show();
        }
    }
}
