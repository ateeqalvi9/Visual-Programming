﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
namespace StudentRegistrationApp
{
    public partial class AddStudents : Form
    {
        string connectionString = @"Data Source=ATTIQUE\SQLEXPRESS;Initial Catalog=StudentDB;Integrated Security=True;Trust Server Certificate=True";
        public AddStudents()
        {
            InitializeComponent();
            cmbGender.Items.AddRange(new string[] { "Male", "Female" });
            cmbDegree.Items.AddRange(new string[] { "BSCS", "BBA", "BSSE" });
        }

        private void btnAddStudent_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text) || string.IsNullOrWhiteSpace(txtFatherName.Text) ||
                string.IsNullOrWhiteSpace(txtCNIC.Text) || string.IsNullOrWhiteSpace(txtAddress.Text) ||
                string.IsNullOrWhiteSpace(cmbGender.Text) || string.IsNullOrWhiteSpace(cmbDegree.Text) ||
                string.IsNullOrWhiteSpace(txtMatric.Text) || string.IsNullOrWhiteSpace(txtInter.Text))
            {
                MessageBox.Show("Please fill all fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = "INSERT INTO Students (Name, FatherName, CNIC, Gender, DOB, Address, DegreeProgram, MatricGrade, InterGrade) " +
                                   "VALUES (@Name, @FatherName, @CNIC, @Gender, @DOB, @Address, @Degree, @Matric, @Inter)";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@Name", txtName.Text);
                    cmd.Parameters.AddWithValue("@FatherName", txtFatherName.Text);
                    cmd.Parameters.AddWithValue("@CNIC", txtCNIC.Text);
                    cmd.Parameters.AddWithValue("@Gender", cmbGender.Text);
                    cmd.Parameters.AddWithValue("@DOB", dtpDOB.Value.Date);
                    cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
                    cmd.Parameters.AddWithValue("@Degree", cmbDegree.Text);
                    cmd.Parameters.AddWithValue("@Matric", Convert.ToDouble(txtMatric.Text));
                    cmd.Parameters.AddWithValue("@Inter", Convert.ToDouble(txtInter.Text));
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Student Added Successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtName.Clear(); txtFatherName.Clear(); txtCNIC.Clear();
                    txtAddress.Clear(); txtMatric.Clear(); txtInter.Clear();
                    cmbGender.SelectedIndex = -1; cmbDegree.SelectedIndex = -1;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
