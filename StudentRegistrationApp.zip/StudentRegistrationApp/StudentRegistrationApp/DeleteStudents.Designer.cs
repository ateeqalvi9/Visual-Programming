﻿namespace StudentRegistrationApp
{
    partial class DeleteStudents
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtRegId = new TextBox();
            btnDelete = new Button();
            SuspendLayout();
            // 
            // txtRegId
            // 
            txtRegId.Location = new Point(65, 26);
            txtRegId.Name = "txtRegId";
            txtRegId.PlaceholderText = "RegID";
            txtRegId.Size = new Size(100, 23);
            txtRegId.TabIndex = 0;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(82, 91);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(75, 23);
            btnDelete.TabIndex = 1;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // DeleteStudents
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnDelete);
            Controls.Add(txtRegId);
            Name = "DeleteStudents";
            Text = "DeleteStudents";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtRegId;
        private Button btnDelete;
    }
}