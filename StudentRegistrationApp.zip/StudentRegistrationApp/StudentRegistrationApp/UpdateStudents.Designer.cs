﻿namespace StudentRegistrationApp
{
    partial class UpdateStudents
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtRegId = new TextBox();
            txtName = new TextBox();
            txtAddress = new TextBox();
            txtMatric = new TextBox();
            txtInter = new TextBox();
            btnUpdate = new Button();
            SuspendLayout();
            // 
            // txtRegId
            // 
            txtRegId.Location = new Point(49, 24);
            txtRegId.Name = "txtRegId";
            txtRegId.PlaceholderText = "RegID";
            txtRegId.Size = new Size(100, 23);
            txtRegId.TabIndex = 0;
            // 
            // txtName
            // 
            txtName.Location = new Point(172, 24);
            txtName.Name = "txtName";
            txtName.PlaceholderText = "Name";
            txtName.Size = new Size(100, 23);
            txtName.TabIndex = 1;
            // 
            // txtAddress
            // 
            txtAddress.Location = new Point(307, 24);
            txtAddress.Name = "txtAddress";
            txtAddress.PlaceholderText = "Address";
            txtAddress.Size = new Size(100, 23);
            txtAddress.TabIndex = 2;
            // 
            // txtMatric
            // 
            txtMatric.Location = new Point(101, 90);
            txtMatric.Name = "txtMatric";
            txtMatric.PlaceholderText = "Matric Grade";
            txtMatric.Size = new Size(100, 23);
            txtMatric.TabIndex = 3;
            // 
            // txtInter
            // 
            txtInter.Location = new Point(240, 90);
            txtInter.Name = "txtInter";
            txtInter.PlaceholderText = "Intermediate Grade";
            txtInter.Size = new Size(119, 23);
            txtInter.TabIndex = 4;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(189, 172);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(75, 23);
            btnUpdate.TabIndex = 5;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // UpdateStudents
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnUpdate);
            Controls.Add(txtInter);
            Controls.Add(txtMatric);
            Controls.Add(txtAddress);
            Controls.Add(txtName);
            Controls.Add(txtRegId);
            Name = "UpdateStudents";
            Text = "UpdateStudents";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtRegId;
        private TextBox txtName;
        private TextBox txtAddress;
        private TextBox txtMatric;
        private TextBox txtInter;
        private Button btnUpdate;
    }
}