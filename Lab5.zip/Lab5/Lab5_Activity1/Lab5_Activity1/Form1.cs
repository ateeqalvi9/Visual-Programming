﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5_Activity1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            lb1Welcome.Text = "Hello World";
            lb1Welcome.Font = new Font("tmes new roman", 20, FontStyle.Regular);
        }
    }
}
