﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5_Task5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Text = "Student Information Form";
            this.Width = 400;
            this.Height = 400;
            cmbCity.Items.Add("Islamabad");
            cmbCity.Items.Add("Lahore");
            cmbCity.Items.Add("Karachi");
            cmbCity.Items.Add("Quetta");
            cmbCity.Items.Add("Peshawar");
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            string gender = "";
            if (rdoMale.Checked)
                gender = "Male";
            else if (rdoFemale.Checked)
                gender = "Female";
            else
                gender = "Not selected";
            string city = cmbCity.SelectedItem != null ? cmbCity.SelectedItem.ToString() : "Not selected";

            lblResult.Text = $"Student Name: {name}\nGender: {gender}\nCity: {city}";
            lblResult.ForeColor = System.Drawing.Color.Blue;
        }
    }
}
