﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5_Task2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Text = "Pizza Toppings Selector";
            this.Size = new Size(500, 400);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.Beige;
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            string toppings = "";

            if (chkCheese.Checked)
                toppings += "Cheese,\n ";
            if (chkPepperoni.Checked)
                toppings += "Pepperoni,\n ";
            if (chkMushrooms.Checked)
                toppings += "Mushrooms,\n ";

            if (toppings == "")
                lblResult.Text = "Please select at least one topping!";
            else
            {
                toppings = toppings.TrimEnd(',', ' ');
                lblResult.Text = "You ordered pizza with:\n " + toppings + " ";
            }

            lblResult.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            lblResult.ForeColor = Color.DarkRed;
        }
    }
}
