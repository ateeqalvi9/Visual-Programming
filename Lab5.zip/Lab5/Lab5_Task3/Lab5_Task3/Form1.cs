﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5_Task3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Text = "Course Registration";
            this.Size = new Size(400, 350);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.LightBlue;
            listCourses.Items.Add("Programming Fundamentals");
            listCourses.Items.Add("Object-Oriented Programming");
            listCourses.Items.Add("Database Systems");
            listCourses.Items.Add("Data Structures");
            listCourses.Items.Add("Operating Systems");
            listCourses.Items.Add("Visual Programming");
            listCourses.SelectionMode = SelectionMode.MultiExtended;
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            if (listCourses.SelectedItems.Count == 0)
            {
                lblResult.Text = "Please select at least one course.";
                return;
            }
            string selectedCourses = "You have registered for:\n";

            foreach (var item in listCourses.SelectedItems)
            {
                selectedCourses += "- " + item.ToString() + "\n";
            }
            lblResult.Text = selectedCourses;
            lblResult.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            lblResult.ForeColor = Color.DarkGreen;
        }
    }
}
