﻿namespace Lab5_Task1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb1Num1 = new System.Windows.Forms.Label();
            this.lb1Num2 = new System.Windows.Forms.Label();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSubtrarct = new System.Windows.Forms.Button();
            this.btnMultiply = new System.Windows.Forms.Button();
            this.btnDivide = new System.Windows.Forms.Button();
            this.lb1Result = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lb1Num1
            // 
            this.lb1Num1.AutoSize = true;
            this.lb1Num1.Location = new System.Drawing.Point(59, 39);
            this.lb1Num1.Name = "lb1Num1";
            this.lb1Num1.Size = new System.Drawing.Size(50, 13);
            this.lb1Num1.TabIndex = 0;
            this.lb1Num1.Text = "Number1";
            // 
            // lb1Num2
            // 
            this.lb1Num2.AutoSize = true;
            this.lb1Num2.Location = new System.Drawing.Point(62, 75);
            this.lb1Num2.Name = "lb1Num2";
            this.lb1Num2.Size = new System.Drawing.Size(50, 13);
            this.lb1Num2.TabIndex = 1;
            this.lb1Num2.Text = "Number2";
            // 
            // txtNum1
            // 
            this.txtNum1.Location = new System.Drawing.Point(123, 39);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(100, 20);
            this.txtNum1.TabIndex = 2;
            // 
            // txtNum2
            // 
            this.txtNum2.Location = new System.Drawing.Point(123, 75);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(100, 20);
            this.txtNum2.TabIndex = 3;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(62, 127);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 4;
            this.btnAdd.Text = "Add(+)";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnSubtrarct
            // 
            this.btnSubtrarct.Location = new System.Drawing.Point(62, 190);
            this.btnSubtrarct.Name = "btnSubtrarct";
            this.btnSubtrarct.Size = new System.Drawing.Size(75, 23);
            this.btnSubtrarct.TabIndex = 5;
            this.btnSubtrarct.Text = "Subtract(-)";
            this.btnSubtrarct.UseVisualStyleBackColor = true;
            this.btnSubtrarct.Click += new System.EventHandler(this.btnSubtrarct_Click);
            // 
            // btnMultiply
            // 
            this.btnMultiply.Location = new System.Drawing.Point(187, 127);
            this.btnMultiply.Name = "btnMultiply";
            this.btnMultiply.Size = new System.Drawing.Size(75, 23);
            this.btnMultiply.TabIndex = 6;
            this.btnMultiply.Text = "Multiply(*)";
            this.btnMultiply.UseVisualStyleBackColor = true;
            this.btnMultiply.Click += new System.EventHandler(this.btnMultiply_Click);
            // 
            // btnDivide
            // 
            this.btnDivide.Location = new System.Drawing.Point(187, 190);
            this.btnDivide.Name = "btnDivide";
            this.btnDivide.Size = new System.Drawing.Size(75, 23);
            this.btnDivide.TabIndex = 7;
            this.btnDivide.Text = "Divide(/)";
            this.btnDivide.UseVisualStyleBackColor = true;
            this.btnDivide.Click += new System.EventHandler(this.btnDivide_Click);
            // 
            // lb1Result
            // 
            this.lb1Result.AutoSize = true;
            this.lb1Result.Location = new System.Drawing.Point(148, 259);
            this.lb1Result.Name = "lb1Result";
            this.lb1Result.Size = new System.Drawing.Size(35, 13);
            this.lb1Result.TabIndex = 8;
            this.lb1Result.Text = "label1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lb1Result);
            this.Controls.Add(this.btnDivide);
            this.Controls.Add(this.btnMultiply);
            this.Controls.Add(this.btnSubtrarct);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.lb1Num2);
            this.Controls.Add(this.lb1Num1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb1Num1;
        private System.Windows.Forms.Label lb1Num2;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnSubtrarct;
        private System.Windows.Forms.Button btnMultiply;
        private System.Windows.Forms.Button btnDivide;
        private System.Windows.Forms.Label lb1Result;
    }
}

