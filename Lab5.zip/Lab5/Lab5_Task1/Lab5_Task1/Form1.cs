﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5_Task1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Text = "Simple Calculator";
            this.Size = new Size(400, 350);               
            this.StartPosition = FormStartPosition.CenterScreen; 
            this.BackColor = Color.LightGray;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (ValidateInput(out double num1, out double num2))
            {
                lb1Result.Text = "Result: " + (num1 + num2).ToString();
            }
        }

        private void btnSubtrarct_Click(object sender, EventArgs e)
        {
            if (ValidateInput(out double num1, out double num2))
                lb1Result.Text = "Result: " + (num1 - num2).ToString();
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            if (ValidateInput(out double num1, out double num2))
                lb1Result.Text = "Result: " + (num1 * num2).ToString();
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            if (ValidateInput(out double num1, out double num2))
            {
                if (num2 == 0)
                    lb1Result.Text = "Cannot divide by zero!";
                else
                    lb1Result.Text = "Result: " + (num1 / num2).ToString("0.##");
            }
        }
        private bool ValidateInput(out double num1, out double num2)
        {
            bool isValid1 = double.TryParse(txtNum1.Text, out num1);
            bool isValid2 = double.TryParse(txtNum2.Text, out num2);

            if (!isValid1 || !isValid2)
            {
                lb1Result.Text = "Please enter valid numbers!";
                return false;
            }
            return true;
        }
    }
}
