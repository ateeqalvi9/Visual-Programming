﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5_Activity5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnResult_Click(object sender, EventArgs e)
        {
            if (ListBoxCities.SelectedItem != null)
            {
                lbResult.Text = "You selected: " + ListBoxCities.SelectedItem.ToString();
            }
            else
            {
                lbResult.Text = "Please enter a city!";
            }
        }
    }
}
