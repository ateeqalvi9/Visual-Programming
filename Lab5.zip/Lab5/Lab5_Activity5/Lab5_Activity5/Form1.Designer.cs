﻿namespace Lab5_Activity5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ListBoxCities = new System.Windows.Forms.ListBox();
            this.lbResult = new System.Windows.Forms.Label();
            this.btnResult = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ListBoxCities
            // 
            this.ListBoxCities.FormattingEnabled = true;
            this.ListBoxCities.Items.AddRange(new object[] {
            "Punjab",
            "Sindh",
            "KPK",
            "Balochistan"});
            this.ListBoxCities.Location = new System.Drawing.Point(50, 48);
            this.ListBoxCities.Name = "ListBoxCities";
            this.ListBoxCities.Size = new System.Drawing.Size(99, 69);
            this.ListBoxCities.TabIndex = 0;
            // 
            // lbResult
            // 
            this.lbResult.AutoSize = true;
            this.lbResult.Location = new System.Drawing.Point(253, 60);
            this.lbResult.Name = "lbResult";
            this.lbResult.Size = new System.Drawing.Size(35, 13);
            this.lbResult.TabIndex = 1;
            this.lbResult.Text = "label1";
            // 
            // btnResult
            // 
            this.btnResult.Location = new System.Drawing.Point(244, 94);
            this.btnResult.Name = "btnResult";
            this.btnResult.Size = new System.Drawing.Size(75, 23);
            this.btnResult.TabIndex = 2;
            this.btnResult.Text = "Enter";
            this.btnResult.UseVisualStyleBackColor = true;
            this.btnResult.Click += new System.EventHandler(this.btnResult_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnResult);
            this.Controls.Add(this.lbResult);
            this.Controls.Add(this.ListBoxCities);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListBox ListBoxCities;
        private System.Windows.Forms.Label lbResult;
        private System.Windows.Forms.Button btnResult;
    }
}

