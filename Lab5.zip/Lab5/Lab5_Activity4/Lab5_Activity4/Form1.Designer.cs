﻿namespace Lab5_Activity4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Cpp = new System.Windows.Forms.CheckBox();
            this.Cs = new System.Windows.Forms.CheckBox();
            this.VB = new System.Windows.Forms.CheckBox();
            this.Java = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnEnter = new System.Windows.Forms.Button();
            this.lb2Result = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Cpp
            // 
            this.Cpp.AutoSize = true;
            this.Cpp.Location = new System.Drawing.Point(85, 154);
            this.Cpp.Name = "Cpp";
            this.Cpp.Size = new System.Drawing.Size(45, 17);
            this.Cpp.TabIndex = 0;
            this.Cpp.Text = "C++";
            this.Cpp.UseVisualStyleBackColor = true;
            // 
            // Cs
            // 
            this.Cs.AutoSize = true;
            this.Cs.Location = new System.Drawing.Point(85, 178);
            this.Cs.Name = "Cs";
            this.Cs.Size = new System.Drawing.Size(40, 17);
            this.Cs.TabIndex = 1;
            this.Cs.Text = "C#";
            this.Cs.UseVisualStyleBackColor = true;
            // 
            // VB
            // 
            this.VB.AutoSize = true;
            this.VB.Location = new System.Drawing.Point(85, 202);
            this.VB.Name = "VB";
            this.VB.Size = new System.Drawing.Size(40, 17);
            this.VB.TabIndex = 2;
            this.VB.Text = "VB";
            this.VB.UseVisualStyleBackColor = true;
            // 
            // Java
            // 
            this.Java.AutoSize = true;
            this.Java.Location = new System.Drawing.Point(85, 226);
            this.Java.Name = "Java";
            this.Java.Size = new System.Drawing.Size(49, 17);
            this.Java.TabIndex = 3;
            this.Java.Text = "Java";
            this.Java.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(82, 124);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Select Programming Language";
            // 
            // btnEnter
            // 
            this.btnEnter.Location = new System.Drawing.Point(265, 266);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(75, 23);
            this.btnEnter.TabIndex = 5;
            this.btnEnter.Text = "Enter";
            this.btnEnter.UseVisualStyleBackColor = true;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // lb2Result
            // 
            this.lb2Result.AutoSize = true;
            this.lb2Result.Location = new System.Drawing.Point(286, 330);
            this.lb2Result.Name = "lb2Result";
            this.lb2Result.Size = new System.Drawing.Size(35, 13);
            this.lb2Result.TabIndex = 6;
            this.lb2Result.Text = "label2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lb2Result);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Java);
            this.Controls.Add(this.VB);
            this.Controls.Add(this.Cs);
            this.Controls.Add(this.Cpp);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox Cpp;
        private System.Windows.Forms.CheckBox Cs;
        private System.Windows.Forms.CheckBox VB;
        private System.Windows.Forms.CheckBox Java;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.Label lb2Result;
    }
}

