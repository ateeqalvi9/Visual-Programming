﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5_Activity4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            string selected = "You selected:\n ";
            if (Cpp.Checked)
            {
                selected += "Cpp\n";

            }
            if (Cs.Checked)
            {
                selected += "Cs\n";
            }
            if (VB.Checked)
            {
                selected += "VB\n";
            }
            if (Java.Checked)
            {
                selected += "Java\n";
            }
            if (selected == "You selected: ")
            {
                selected += "None\n";
            }
            lb2Result.Text = selected;
        }
    }
}
