﻿namespace Lab5_Activity3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnHello = new System.Windows.Forms.Button();
            this.lb2Result = new System.Windows.Forms.Label();
            this.lb1name = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnHello
            // 
            this.btnHello.Location = new System.Drawing.Point(499, 181);
            this.btnHello.Name = "btnHello";
            this.btnHello.Size = new System.Drawing.Size(75, 23);
            this.btnHello.TabIndex = 7;
            this.btnHello.Text = "Enter";
            this.btnHello.UseVisualStyleBackColor = true;
            this.btnHello.Click += new System.EventHandler(this.btnHello_Click_1);
            // 
            // lb2Result
            // 
            this.lb2Result.AutoSize = true;
            this.lb2Result.Location = new System.Drawing.Point(373, 256);
            this.lb2Result.Name = "lb2Result";
            this.lb2Result.Size = new System.Drawing.Size(35, 13);
            this.lb2Result.TabIndex = 6;
            this.lb2Result.Text = "label2";
            this.lb2Result.Click += new System.EventHandler(this.lb2Result_Click_1);
            // 
            // lb1name
            // 
            this.lb1name.AutoSize = true;
            this.lb1name.Location = new System.Drawing.Point(227, 192);
            this.lb1name.Name = "lb1name";
            this.lb1name.Size = new System.Drawing.Size(63, 13);
            this.lb1name.TabIndex = 5;
            this.lb1name.Text = "Enter Name";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(334, 185);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 4;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnHello);
            this.Controls.Add(this.lb2Result);
            this.Controls.Add(this.lb1name);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnHello;
        private System.Windows.Forms.Label lb2Result;
        private System.Windows.Forms.Label lb1name;
        private System.Windows.Forms.TextBox textBox1;
    }
}

