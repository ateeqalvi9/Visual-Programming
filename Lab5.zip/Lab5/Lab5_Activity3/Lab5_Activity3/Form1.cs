﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5_Activity3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void lb2Result_Click_1(object sender, EventArgs e)
        {

        }
        private void btnHello_Click_1(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            if (string.IsNullOrEmpty(name))
            {
                lb2Result.Text = "Hello";
            }
            else
            {
                lb2Result.Text = $"Welcome {name} !";
            }
        }
    }
    }
