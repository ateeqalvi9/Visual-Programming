﻿using Microsoft.AspNetCore.Mvc;
using BookStoreAPI.Models;
using System.Collections.Generic;
using System.Linq;

namespace BookStoreAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BooksController : ControllerBase
    {
        // Static list acts as a temporary database for this lab
        private static List<Book> books = new List<Book>
        {
            new Book { BookId = 1, BookTitle = "C# Basics", Author = "Ali" },
            new Book { BookId = 2, BookTitle = "ASP.NET Core", Author = "Ahmed" }
        };

        // GET: api/books
        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(books);
        }

        // GET: api/books/1
        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var book = books.FirstOrDefault(b => b.BookId == id);

            if (book == null)
            {
                return NotFound(new { Message = $"Book with ID {id} not found." });
            }

            return Ok(book);
        }

        // POST: api/books
        [HttpPost]
        public IActionResult Create([FromBody] Book book)
        {
            if (book == null)
            {
                return BadRequest("Invalid data.");
            }

            // Simple auto-increment logic
            book.BookId = books.Count > 0 ? books.Max(b => b.BookId) + 1 : 1;

            books.Add(book);

            // Returns HTTP 201 Created and the location of the new resource
            return CreatedAtAction(nameof(GetById), new { id = book.BookId }, book);
        }

        // PUT: api/books/1
        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody] Book updatedBook)
        {
            var book = books.FirstOrDefault(b => b.BookId == id);

            if (book == null)
            {
                return NotFound(new { Message = $"Book with ID {id} not found." });
            }

            book.BookTitle = updatedBook.BookTitle;
            book.Author = updatedBook.Author;

            return Ok(book);
        }

        // DELETE: api/books/1
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var book = books.FirstOrDefault(b => b.BookId == id);

            if (book == null)
            {
                return NotFound(new { Message = $"Book with ID {id} not found." });
            }

            books.Remove(book);
            return Ok(new { Message = "Book deleted successfully.", CurrentList = books });
        }
    }
}