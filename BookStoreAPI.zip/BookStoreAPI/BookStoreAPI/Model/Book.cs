﻿namespace BookStoreAPI.Models
{
    public class Book
    {
        public int BookId { get; set; }
        public string BookTitle { get; set; } = string.Empty; // Initialized to avoid null warnings
        public string Author { get; set; } = string.Empty;
    }
}