CREATE DATABASE LibraryDB;
GO
USE LibraryDB;
GO
CREATE TABLE Books (
    BookID INT IDENTITY(1,1) PRIMARY KEY,
    Title NVARCHAR(250) NOT NULL,
    Author NVARCHAR(200) NOT NULL,
    Publisher NVARCHAR(200) NULL,
    Category NVARCHAR(100) NULL,
    ISBN NVARCHAR(50) NULL,
    Quantity INT NOT NULL DEFAULT 0,
    Price DECIMAL(10,2) NULL,
    RackNo NVARCHAR(50) NULL,
    DateAdded DATE NOT NULL DEFAULT(GETDATE())
);
GO
CREATE TABLE Users (
    UserID INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(100) UNIQUE NOT NULL,
    PasswordHash NVARCHAR(200) NOT NULL, -- store hash in real app; for lab plain is acceptable
    FullName NVARCHAR(200) NULL,
    IsAdmin BIT NOT NULL DEFAULT 1
);
GO
INSERT INTO Users (Username, PasswordHash, FullName)
VALUES ('librarian', 'password123', 'Default Librarian'); -- For lab use; ideally hash passwords.
GO

INSERT INTO Books (Title, Author, Publisher, Category, ISBN, Quantity, Price, RackNo)
VALUES
('Introduction to Algorithms', 'Cormen, Leiserson, Rivest, Stein', 'MIT Press', 'Computer Science', '0262033844', 3, 150.00, 'CS-01'),
('Programming C# 8.0', 'Ian Griffiths', 'O''Reilly', 'Computer Science', '1492051136', 5, 120.00, 'CS-02');
GO
USE LibraryDB
INSERT INTO Users (Username, PasswordHash, FullName) VALUES ('Asma', '1234', 'Asma');
GO
