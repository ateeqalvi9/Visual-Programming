﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace LibraryStockManagement
{
    public partial class DeleteBookForm : Form
    {
        string connectionString =
            "Data Source=ATTIQUE\\SQLEXPRESS;Initial Catalog=LibraryDB;Integrated Security=True;Trust Server Certificate=True";

        public DeleteBookForm()
        {
            InitializeComponent();
        }

        private void DeleteBookForm_Load(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string query = "SELECT BookID, Title, Author, Title + ' - ' + Author AS DisplayName FROM Books";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    cmbBookID.DataSource = dt;
                    cmbBookID.DisplayMember = "DisplayName";
                    cmbBookID.ValueMember = "BookID";
                    cmbBookID.SelectedIndex = -1;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading books: " + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (cmbBookID.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a book to delete.");
                return;
            }
            if (MessageBox.Show("Are you sure you want to delete this book?", "Confirm Delete", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();
                        int selectedBookID = Convert.ToInt32(cmbBookID.SelectedValue);
                        string selectQuery = "SELECT Title, Author FROM Books WHERE BookID=@BookID";
                        SqlCommand selectCmd = new SqlCommand(selectQuery, conn);
                        selectCmd.Parameters.AddWithValue("@BookID", selectedBookID);

                        SqlDataReader reader = selectCmd.ExecuteReader();
                        if (reader.Read())
                        {
                            string title = reader["Title"].ToString();
                            string author = reader["Author"].ToString();
                            reader.Close();
                            string deleteQuery = "DELETE FROM Books WHERE Title=@Title AND Author=@Author";
                            SqlCommand deleteCmd = new SqlCommand(deleteQuery, conn);
                            deleteCmd.Parameters.AddWithValue("@Title", title);
                            deleteCmd.Parameters.AddWithValue("@Author", author);

                            int rowsAffected = deleteCmd.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Book deleted successfully!");
                            }
                            else
                            {
                                MessageBox.Show("No book found to delete with the selected Title and Author.");
                            }

                            DeleteBookForm_Load(sender, e); 
                        }
                        else
                        {
                            reader.Close();
                            MessageBox.Show("Selected book not found in database.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error deleting book: " + ex.Message);
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
