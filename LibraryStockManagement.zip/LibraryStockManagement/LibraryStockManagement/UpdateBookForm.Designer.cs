﻿namespace LibraryStockManagement
{
    partial class UpdateBookForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCancel = new Button();
            btnAction = new Button();
            dtpDateAdded = new DateTimePicker();
            txtRackNo = new TextBox();
            txtPrice = new TextBox();
            nudQuantity = new NumericUpDown();
            cmbCategory = new ComboBox();
            txtISBN = new TextBox();
            txtPublisher = new TextBox();
            txtAuthor = new TextBox();
            txtTitle = new TextBox();
            nudBookID = new NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)nudQuantity).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudBookID).BeginInit();
            SuspendLayout();
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(253, 269);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 21;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnAction
            // 
            btnAction.Location = new Point(144, 269);
            btnAction.Name = "btnAction";
            btnAction.Size = new Size(75, 23);
            btnAction.TabIndex = 20;
            btnAction.Text = "Save";
            btnAction.UseVisualStyleBackColor = true;
            btnAction.Click += btnAction_Click;
            // 
            // dtpDateAdded
            // 
            dtpDateAdded.Location = new Point(352, 203);
            dtpDateAdded.Name = "dtpDateAdded";
            dtpDateAdded.Size = new Size(200, 23);
            dtpDateAdded.TabIndex = 19;
            // 
            // txtRackNo
            // 
            txtRackNo.Location = new Point(204, 193);
            txtRackNo.Name = "txtRackNo";
            txtRackNo.PlaceholderText = "RackNo";
            txtRackNo.Size = new Size(100, 23);
            txtRackNo.TabIndex = 18;
            // 
            // txtPrice
            // 
            txtPrice.Location = new Point(62, 193);
            txtPrice.Name = "txtPrice";
            txtPrice.PlaceholderText = "Price";
            txtPrice.Size = new Size(100, 23);
            txtPrice.TabIndex = 17;
            // 
            // nudQuantity
            // 
            nudQuantity.Location = new Point(352, 140);
            nudQuantity.Name = "nudQuantity";
            nudQuantity.Size = new Size(120, 23);
            nudQuantity.TabIndex = 16;
            // 
            // cmbCategory
            // 
            cmbCategory.FormattingEnabled = true;
            cmbCategory.Items.AddRange(new object[] { "Sci-FI", "Fiction", "Novel" });
            cmbCategory.Location = new Point(62, 139);
            cmbCategory.Name = "cmbCategory";
            cmbCategory.Size = new Size(121, 23);
            cmbCategory.TabIndex = 15;
            // 
            // txtISBN
            // 
            txtISBN.Location = new Point(204, 139);
            txtISBN.Name = "txtISBN";
            txtISBN.PlaceholderText = "ISBN";
            txtISBN.Size = new Size(100, 23);
            txtISBN.TabIndex = 14;
            // 
            // txtPublisher
            // 
            txtPublisher.Location = new Point(352, 82);
            txtPublisher.Name = "txtPublisher";
            txtPublisher.PlaceholderText = "Publisher";
            txtPublisher.Size = new Size(100, 23);
            txtPublisher.TabIndex = 13;
            // 
            // txtAuthor
            // 
            txtAuthor.Location = new Point(204, 82);
            txtAuthor.Name = "txtAuthor";
            txtAuthor.PlaceholderText = "Author";
            txtAuthor.Size = new Size(100, 23);
            txtAuthor.TabIndex = 12;
            // 
            // txtTitle
            // 
            txtTitle.Location = new Point(62, 82);
            txtTitle.Name = "txtTitle";
            txtTitle.PlaceholderText = "Title";
            txtTitle.Size = new Size(100, 23);
            txtTitle.TabIndex = 11;
            // 
            // nudBookID
            // 
            nudBookID.Location = new Point(182, 33);
            nudBookID.Name = "nudBookID";
            nudBookID.Size = new Size(120, 23);
            nudBookID.TabIndex = 22;
            // 
            // UpdateBookForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(nudBookID);
            Controls.Add(btnCancel);
            Controls.Add(btnAction);
            Controls.Add(dtpDateAdded);
            Controls.Add(txtRackNo);
            Controls.Add(txtPrice);
            Controls.Add(nudQuantity);
            Controls.Add(cmbCategory);
            Controls.Add(txtISBN);
            Controls.Add(txtPublisher);
            Controls.Add(txtAuthor);
            Controls.Add(txtTitle);
            Name = "UpdateBookForm";
            Text = "UpdateBookForm";
            ((System.ComponentModel.ISupportInitialize)nudQuantity).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudBookID).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCancel;
        private Button btnAction;
        private DateTimePicker dtpDateAdded;
        private TextBox txtRackNo;
        private TextBox txtPrice;
        private NumericUpDown nudQuantity;
        private ComboBox cmbCategory;
        private TextBox txtISBN;
        private TextBox txtPublisher;
        private TextBox txtAuthor;
        private TextBox txtTitle;
        private NumericUpDown nudBookID;
    }
}