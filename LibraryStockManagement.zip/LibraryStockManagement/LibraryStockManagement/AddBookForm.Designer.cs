﻿namespace LibraryStockManagement
{
    partial class AddBookForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtTitle = new TextBox();
            txtAuthor = new TextBox();
            txtPublisher = new TextBox();
            txtISBN = new TextBox();
            cmbCategory = new ComboBox();
            nudQuantity = new NumericUpDown();
            txtPrice = new TextBox();
            txtRackNo = new TextBox();
            dtpDateAdded = new DateTimePicker();
            btnSave = new Button();
            btnCancel = new Button();
            ((System.ComponentModel.ISupportInitialize)nudQuantity).BeginInit();
            SuspendLayout();
            // 
            // txtTitle
            // 
            txtTitle.Location = new Point(46, 24);
            txtTitle.Name = "txtTitle";
            txtTitle.PlaceholderText = "Title";
            txtTitle.Size = new Size(100, 23);
            txtTitle.TabIndex = 0;
            // 
            // txtAuthor
            // 
            txtAuthor.Location = new Point(188, 24);
            txtAuthor.Name = "txtAuthor";
            txtAuthor.PlaceholderText = "Author";
            txtAuthor.Size = new Size(100, 23);
            txtAuthor.TabIndex = 1;
            // 
            // txtPublisher
            // 
            txtPublisher.Location = new Point(336, 24);
            txtPublisher.Name = "txtPublisher";
            txtPublisher.PlaceholderText = "Publisher";
            txtPublisher.Size = new Size(100, 23);
            txtPublisher.TabIndex = 2;
            // 
            // txtISBN
            // 
            txtISBN.Location = new Point(188, 81);
            txtISBN.Name = "txtISBN";
            txtISBN.PlaceholderText = "ISBN";
            txtISBN.Size = new Size(100, 23);
            txtISBN.TabIndex = 3;
            // 
            // cmbCategory
            // 
            cmbCategory.FormattingEnabled = true;
            cmbCategory.Items.AddRange(new object[] { "Sci-FI", "Fiction", "Novel" });
            cmbCategory.Location = new Point(46, 81);
            cmbCategory.Name = "cmbCategory";
            cmbCategory.Size = new Size(121, 23);
            cmbCategory.TabIndex = 4;
            // 
            // nudQuantity
            // 
            nudQuantity.Location = new Point(336, 82);
            nudQuantity.Name = "nudQuantity";
            nudQuantity.Size = new Size(120, 23);
            nudQuantity.TabIndex = 5;
            // 
            // txtPrice
            // 
            txtPrice.Location = new Point(46, 135);
            txtPrice.Name = "txtPrice";
            txtPrice.PlaceholderText = "Price";
            txtPrice.Size = new Size(100, 23);
            txtPrice.TabIndex = 6;
            // 
            // txtRackNo
            // 
            txtRackNo.Location = new Point(188, 135);
            txtRackNo.Name = "txtRackNo";
            txtRackNo.PlaceholderText = "RackNo";
            txtRackNo.Size = new Size(100, 23);
            txtRackNo.TabIndex = 7;
            // 
            // dtpDateAdded
            // 
            dtpDateAdded.Location = new Point(336, 145);
            dtpDateAdded.Name = "dtpDateAdded";
            dtpDateAdded.Size = new Size(200, 23);
            dtpDateAdded.TabIndex = 8;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(128, 211);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 9;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(237, 211);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 10;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            // 
            // AddBookForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(dtpDateAdded);
            Controls.Add(txtRackNo);
            Controls.Add(txtPrice);
            Controls.Add(nudQuantity);
            Controls.Add(cmbCategory);
            Controls.Add(txtISBN);
            Controls.Add(txtPublisher);
            Controls.Add(txtAuthor);
            Controls.Add(txtTitle);
            Name = "AddBookForm";
            Text = "AddBookForm";
            ((System.ComponentModel.ISupportInitialize)nudQuantity).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtTitle;
        private TextBox txtAuthor;
        private TextBox txtPublisher;
        private TextBox txtISBN;
        private ComboBox cmbCategory;
        private NumericUpDown nudQuantity;
        private TextBox txtPrice;
        private TextBox txtRackNo;
        private DateTimePicker dtpDateAdded;
        private Button btnSave;
        private Button btnCancel;
    }
}