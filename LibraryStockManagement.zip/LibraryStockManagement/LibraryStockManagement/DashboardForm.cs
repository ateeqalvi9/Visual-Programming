﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryStockManagement
{
    public partial class DashboardForm : Form
    {
        public DashboardForm()
        {
            InitializeComponent();
        }

        private void addBooksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddBookForm add = new AddBookForm();
            add.Show();
        }

        private void viewBooksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewBooksForm view = new ViewBooksForm();
            view.Show();
        }

        private void updateBooksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateBookForm update = new UpdateBookForm();
            update.Show();
        }

        private void deleteBooksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteBookForm delete = new DeleteBookForm();
            delete.Show();
        }
    }
}
