﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace LibraryStockManagement
{
    public partial class UpdateBookForm : Form
    {
        string connectionString =
            "Data Source=ATTIQUE\\SQLEXPRESS;Initial Catalog=LibraryDB;Integrated Security=True;Trust Server Certificate=True";
        public int BookIDToUpdate { get; set; } = 0;
        string originalTitle = "";
        string originalAuthor = "";
        string originalPublisher = "";
        string originalCategory = "";
        string originalISBN = "";
        int originalQuantity = 0;
        decimal originalPrice = 0;
        string originalRack = "";
        DateTime originalDate;

        public UpdateBookForm()
        {
            InitializeComponent();
        }

        private void UpdateBookForm_Load(object sender, EventArgs e)
        {
            if (BookIDToUpdate > 0)
            {
                LoadBookData();
                btnAction.Text = "Update Book";
            }
        }
        private void LoadBookData()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    SqlCommand cmd = new SqlCommand("SELECT * FROM Books WHERE BookID=@id", conn);
                    cmd.Parameters.AddWithValue("@id", BookIDToUpdate);

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        txtTitle.Text = reader["Title"].ToString();
                        txtAuthor.Text = reader["Author"].ToString();
                        txtPublisher.Text = reader["Publisher"].ToString();
                        cmbCategory.Text = reader["Category"].ToString();
                        txtISBN.Text = reader["ISBN"].ToString();
                        nudQuantity.Value = Convert.ToInt32(reader["Quantity"]);
                        txtPrice.Text = reader["Price"].ToString();
                        txtRackNo.Text = reader["RackNo"].ToString();
                        dtpDateAdded.Value = Convert.ToDateTime(reader["DateAdded"]);

                        originalTitle = reader["Title"].ToString();
                        originalAuthor = reader["Author"].ToString();
                        originalPublisher = reader["Publisher"].ToString();
                        originalCategory = reader["Category"].ToString();
                        originalISBN = reader["ISBN"].ToString();
                        originalQuantity = Convert.ToInt32(reader["Quantity"]);
                        originalPrice = Convert.ToDecimal(reader["Price"]);
                        originalRack = reader["RackNo"].ToString();
                        originalDate = Convert.ToDateTime(reader["DateAdded"]);
                    }
                    else
                    {
                        MessageBox.Show("Book not found in database!");
                        this.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading book: " + ex.Message);
            }
        }
        private void btnAction_Click(object sender, EventArgs e)
        {
            try
            {
                List<string> updates = new List<string>();
                SqlCommand cmd;

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    cmd = new SqlCommand();
                    cmd.Connection = conn;
                    if (txtTitle.Text != originalTitle)
                    {
                        updates.Add("Title=@Title");
                        cmd.Parameters.AddWithValue("@Title", txtTitle.Text);
                    }
                    if (txtAuthor.Text != originalAuthor)
                    {
                        updates.Add("Author=@Author");
                        cmd.Parameters.AddWithValue("@Author", txtAuthor.Text);
                    }
                    if (txtPublisher.Text != originalPublisher)
                    {
                        updates.Add("Publisher=@Publisher");
                        cmd.Parameters.AddWithValue("@Publisher", txtPublisher.Text);
                    }
                    if (cmbCategory.Text != originalCategory)
                    {
                        updates.Add("Category=@Category");
                        cmd.Parameters.AddWithValue("@Category", cmbCategory.Text);
                    }
                    if (txtISBN.Text != originalISBN)
                    {
                        updates.Add("ISBN=@ISBN");
                        cmd.Parameters.AddWithValue("@ISBN", txtISBN.Text);
                    }
                    if (nudQuantity.Value != originalQuantity)
                    {
                        updates.Add("Quantity=@Quantity");
                        cmd.Parameters.AddWithValue("@Quantity", Convert.ToInt32(nudQuantity.Value));
                    }
                    if (decimal.TryParse(txtPrice.Text, out decimal newPrice))
                    {
                        if (newPrice != originalPrice)
                        {
                            updates.Add("Price=@Price");
                            cmd.Parameters.AddWithValue("@Price", newPrice);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid price value!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    if (txtRackNo.Text != originalRack)
                    {
                        updates.Add("RackNo=@RackNo");
                        cmd.Parameters.AddWithValue("@RackNo", txtRackNo.Text);
                    }

                    if (dtpDateAdded.Value.Date != originalDate.Date)
                    {
                        updates.Add("DateAdded=@DateAdded");
                        cmd.Parameters.AddWithValue("@DateAdded", dtpDateAdded.Value.Date);
                    }
                    if (updates.Count == 0)
                    {
                        MessageBox.Show("No changes detected.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                    string updateQuery = "UPDATE Books SET " + string.Join(", ", updates) + " WHERE BookID=@BookID";
                    cmd.CommandText = updateQuery;
                    cmd.Parameters.AddWithValue("@BookID", (int)nudBookID.Value);

                    int rows = cmd.ExecuteNonQuery();

                    if (rows > 0)
                        MessageBox.Show("Book updated successfully!");
                    else
                        MessageBox.Show("Update failed! Check BookID and database.");
                }

                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating book: " + ex.Message);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
