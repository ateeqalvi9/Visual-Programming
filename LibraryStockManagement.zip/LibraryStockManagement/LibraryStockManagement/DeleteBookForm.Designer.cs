﻿namespace LibraryStockManagement
{
    partial class DeleteBookForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbBookID = new ComboBox();
            btnDelete = new Button();
            btnCancel = new Button();
            SuspendLayout();
            // 
            // cmbBookID
            // 
            cmbBookID.AutoCompleteCustomSource.AddRange(new string[] { "Introduction to Algorithms - Cormen, Leiserson, Rivest, Stein", "Programming C# 8.0 - Ian Griffiths", "abc - xyz", "xyz - abc" });
            cmbBookID.FormattingEnabled = true;
            cmbBookID.Items.AddRange(new object[] { "Introduction to Algorithms - Cormen, Leiserson, Rivest, Stein", "Programming C# 8.0 - Ian Griffiths", "abc - xyz", "xyz - abc" });
            cmbBookID.Location = new Point(83, 33);
            cmbBookID.Name = "cmbBookID";
            cmbBookID.Size = new Size(121, 23);
            cmbBookID.TabIndex = 0;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(93, 91);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(75, 23);
            btnDelete.TabIndex = 1;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(198, 91);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 2;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            // 
            // DeleteBookForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnCancel);
            Controls.Add(btnDelete);
            Controls.Add(cmbBookID);
            Name = "DeleteBookForm";
            Text = "DeleteBookForm";
            ResumeLayout(false);
        }

        #endregion

        private ComboBox cmbBookID;
        private Button btnDelete;
        private Button btnCancel;
    }
}