﻿namespace LibraryStockManagement
{
    partial class DashboardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            formsToolStripMenuItem = new ToolStripMenuItem();
            addBooksToolStripMenuItem = new ToolStripMenuItem();
            viewBooksToolStripMenuItem = new ToolStripMenuItem();
            updateBooksToolStripMenuItem = new ToolStripMenuItem();
            deleteBooksToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { formsToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // formsToolStripMenuItem
            // 
            formsToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { addBooksToolStripMenuItem, viewBooksToolStripMenuItem, updateBooksToolStripMenuItem, deleteBooksToolStripMenuItem });
            formsToolStripMenuItem.Name = "formsToolStripMenuItem";
            formsToolStripMenuItem.Size = new Size(52, 20);
            formsToolStripMenuItem.Text = "Forms";
            // 
            // addBooksToolStripMenuItem
            // 
            addBooksToolStripMenuItem.Name = "addBooksToolStripMenuItem";
            addBooksToolStripMenuItem.Size = new Size(180, 22);
            addBooksToolStripMenuItem.Text = "Add Books";
            addBooksToolStripMenuItem.Click += addBooksToolStripMenuItem_Click;
            // 
            // viewBooksToolStripMenuItem
            // 
            viewBooksToolStripMenuItem.Name = "viewBooksToolStripMenuItem";
            viewBooksToolStripMenuItem.Size = new Size(180, 22);
            viewBooksToolStripMenuItem.Text = "View Books";
            viewBooksToolStripMenuItem.Click += viewBooksToolStripMenuItem_Click;
            // 
            // updateBooksToolStripMenuItem
            // 
            updateBooksToolStripMenuItem.Name = "updateBooksToolStripMenuItem";
            updateBooksToolStripMenuItem.Size = new Size(180, 22);
            updateBooksToolStripMenuItem.Text = "Update Books";
            updateBooksToolStripMenuItem.Click += updateBooksToolStripMenuItem_Click;
            // 
            // deleteBooksToolStripMenuItem
            // 
            deleteBooksToolStripMenuItem.Name = "deleteBooksToolStripMenuItem";
            deleteBooksToolStripMenuItem.Size = new Size(180, 22);
            deleteBooksToolStripMenuItem.Text = "Delete Books";
            deleteBooksToolStripMenuItem.Click += deleteBooksToolStripMenuItem_Click;
            // 
            // DashboardForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "DashboardForm";
            Text = "DashboardForm";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem formsToolStripMenuItem;
        private ToolStripMenuItem addBooksToolStripMenuItem;
        private ToolStripMenuItem viewBooksToolStripMenuItem;
        private ToolStripMenuItem updateBooksToolStripMenuItem;
        private ToolStripMenuItem deleteBooksToolStripMenuItem;
    }
}