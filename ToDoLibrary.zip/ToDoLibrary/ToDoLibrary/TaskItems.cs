﻿using System;
namespace ToDoLibrary
{
    public class TaskItem
    {
        private int _taskId;
        private string _title;
        private string _description;
        private DateTime _dueDate;
        private bool _isCompleted;
        public int TaskId
        {
            get => _taskId;
            internal set => _taskId = value; 
        }

        public string Title
        {
            get => _title;
            set => _title = value ?? string.Empty;
        }
        public string Description
        {
            get => _description;
            set => _description = value ?? string.Empty;
        }
        public DateTime DueDate
        {
            get => _dueDate;
            set => _dueDate = value;
        }
        public bool IsCompleted
        {
            get => _isCompleted;
            set => _isCompleted = value;
        }
        public TaskItem() { }
        public TaskItem(string title, string description, DateTime dueDate)
        {
            Title = title;
            Description = description;
            DueDate = dueDate;
            IsCompleted = false;
        }
        public override string ToString()
        {
            return $"{TaskId}: {Title} {(IsCompleted ? "(Completed)" : "")}";
        }
    }
}
