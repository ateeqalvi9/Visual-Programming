﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ToDoLibrary
{
    public class TaskManager
    {
        private readonly List<TaskItem> _tasks = new List<TaskItem>();
        private int _nextId = 1;
        public void AddTask(TaskItem task)
        {
            if (task == null) throw new ArgumentNullException(nameof(task));
            task.TaskId = _nextId++;
            _tasks.Add(task);
        }
        public bool UpdateTask(int id, TaskItem updatedTask)
        {
            var existing = _tasks.FirstOrDefault(t => t.TaskId == id);
            if (existing == null) return false;

            existing.Title = updatedTask.Title;
            existing.Description = updatedTask.Description;
            existing.DueDate = updatedTask.DueDate;
            existing.IsCompleted = updatedTask.IsCompleted;
            return true;
        }
        public bool DeleteTask(int id)
        {
            var task = _tasks.FirstOrDefault(t => t.TaskId == id);
            if (task == null) return false;
            _tasks.Remove(task);
            return true;
        }
        public List<TaskItem> GetAllTasks()
        {
            return _tasks.ToList();
        }
        public bool MarkAsCompleted(int id)
        {
            var task = _tasks.FirstOrDefault(t => t.TaskId == id);
            if (task == null) return false;
            task.IsCompleted = true;
            return true;
        }
        public TaskItem GetById(int id)
        {
            return _tasks.FirstOrDefault(t => t.TaskId == id);
        }
    }
}
