﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ToDoLibrary;

namespace ToDo_App
{
    public partial class Form1 : Form
    {
        private TaskManager manager = new TaskManager();

        public Form1()
        {
            InitializeComponent();

            comboFilter.Items.AddRange(new[] { "All", "Completed", "Pending" });
            comboFilter.SelectedIndex = 0;

            btnAdd.Click += btnAdd_Click;
            btnUpdate.Click += btnUpdate_Click;
            btnDelete.Click += btnDelete_Click;
            btnMarkCompleted.Click += btnMarkCompleted_Click;
            dgvTasks.CellClick += dgvTasks_CellContentClick;
            comboFilter.SelectedIndexChanged += comboFilter_SelectedIndexChanged;

            dgvTasks.AllowUserToAddRows = false;
            dgvTasks.ReadOnly = true;
            dgvTasks.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvTasks.MultiSelect = false;
            dgvTasks.AutoGenerateColumns = false;

            if (dgvTasks.Columns.Count == 0)
            {
                dgvTasks.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "TaskId",
                    DataPropertyName = "TaskId",
                    HeaderText = "ID",
                    ReadOnly = true
                });
                dgvTasks.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "Title",
                    DataPropertyName = "Title",
                    HeaderText = "Title",
                    ReadOnly = true
                });
                dgvTasks.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "Description",
                    DataPropertyName = "Description",
                    HeaderText = "Description",
                    ReadOnly = true
                });
                dgvTasks.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "DueDate",
                    DataPropertyName = "DueDate",
                    HeaderText = "Due Date",
                    ReadOnly = true
                });
                dgvTasks.Columns.Add(new DataGridViewCheckBoxColumn
                {
                    Name = "IsCompleted",
                    DataPropertyName = "IsCompleted",
                    HeaderText = "Completed",
                    ReadOnly = true
                });
            }

            RefreshGrid();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                MessageBox.Show("Please enter a task title before adding.");
                return;
            }

            var task = new TaskItem(txtTitle.Text, txtDescription.Text, dtpDueDate.Value);
            manager.AddTask(task);

            comboFilter.SelectedItem = "All";
            RefreshGrid();
            ClearInputs();
            MessageBox.Show("Task added successfully!");
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dgvTasks.CurrentRow == null)
            {
                MessageBox.Show("Please select a task to update.");
                return;
            }

            int id = (int)dgvTasks.CurrentRow.Cells["TaskId"].Value;

            var updated = new TaskItem(txtTitle.Text, txtDescription.Text, dtpDueDate.Value)
            {
                IsCompleted = (bool)dgvTasks.CurrentRow.Cells["IsCompleted"].Value
            };

            if (manager.UpdateTask(id, updated))
            {
                RefreshGrid();
                MessageBox.Show("Task updated successfully!");
            }
            else
            {
                MessageBox.Show("Task not found!");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvTasks.CurrentRow == null)
            {
                MessageBox.Show("Please select a task to delete.");
                return;
            }

            int id = (int)dgvTasks.CurrentRow.Cells["TaskId"].Value;

            if (MessageBox.Show("Are you sure you want to delete this task?", "Confirm Delete", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                if (manager.DeleteTask(id))
                {
                    RefreshGrid();
                    ClearInputs();
                    MessageBox.Show("Task deleted successfully!");
                }
                else
                {
                    MessageBox.Show("Task not found!");
                }
            }
        }

        private void btnMarkCompleted_Click(object sender, EventArgs e)
        {
            if (dgvTasks.CurrentRow == null)
            {
                MessageBox.Show("Please select a task to mark as completed.");
                return;
            }

            int id = (int)dgvTasks.CurrentRow.Cells["TaskId"].Value;
            if (manager.MarkAsCompleted(id))
            {
                comboFilter.SelectedItem = "All";
                RefreshGrid();
                MessageBox.Show("Task marked as completed!");
            }
            else
            {
                MessageBox.Show("Task not found!");
            }
        }

        private void dgvTasks_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvTasks.CurrentRow == null || e.RowIndex < 0) return;

            txtTitle.Text = dgvTasks.CurrentRow.Cells["Title"].Value.ToString();
            txtDescription.Text = dgvTasks.CurrentRow.Cells["Description"].Value.ToString();
            dtpDueDate.Value = (DateTime)dgvTasks.CurrentRow.Cells["DueDate"].Value;
        }

        private void comboFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            RefreshGrid();
        }

        private void RefreshGrid()
        {
            var tasks = manager.GetAllTasks();

            string filter = comboFilter.SelectedItem?.ToString() ?? "All";
            if (filter == "Completed")
                tasks = tasks.Where(t => t.IsCompleted).ToList();
            else if (filter == "Pending")
                tasks = tasks.Where(t => !t.IsCompleted).ToList();

            dgvTasks.DataSource = null;
            dgvTasks.DataSource = tasks;
            dgvTasks.AutoResizeColumns();
        }

        private void ClearInputs()
        {
            txtTitle.Clear();
            txtDescription.Clear();
            dtpDueDate.Value = DateTime.Now;
        }

        private bool isDarkMode = false;
        private void btnDarkMode_Click_1(object sender, EventArgs e)
        {
            if (!isDarkMode)
            {
                this.BackColor = Color.DarkGray;
                foreach (Control ctrl in this.Controls)
                {
                    ctrl.ForeColor = Color.White;
                    ctrl.BackColor = Color.FromArgb(30, 30, 30);
                }
                btnDarkMode.Text = "Light Mode";
                isDarkMode = true;
            }
            else
            {
                this.BackColor = Color.White;
                foreach (Control ctrl in this.Controls)
                {
                    ctrl.ForeColor = Color.Black;
                    ctrl.BackColor = Color.White;
                }
                btnDarkMode.Text = "Dark Mode";
                isDarkMode = false;
            }
        }
    }
}
