﻿// Models/Book.cs
using System.ComponentModel.DataAnnotations;

namespace LibraryWebApp.Models
{
    public class Book
    {
        [Required]
        [Key]
        [Display(Name = "Book ID")]
        public int BookId { get; set; }

        [Required]
        [Display(Name = "Title of Book")]
        [MaxLength(100)]
        public string? BookTitle { get; set; }

        [Display(Name = "Author")]
        public string? Author { get; set; }
    }
}
