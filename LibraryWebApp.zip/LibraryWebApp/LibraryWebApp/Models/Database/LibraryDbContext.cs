﻿// Models/Database/LibraryDbContext.cs
using Microsoft.EntityFrameworkCore;
using LibraryWebApp.Models;

namespace LibraryWebApp.Models.Database
{
    public class LibraryDbContext : DbContext
    {
        public LibraryDbContext(DbContextOptions<LibraryDbContext> option) : base(option)
        {
        }

        public DbSet<Book> Books { get; set; }     // This DbSet represents the 'Books' table in our database
        // Note: EF Core will automatically pluralize the table name to 'Books'.

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<Book>()
                .Property(b => b.BookId)
                .ValueGeneratedNever();


        }
    }
}
