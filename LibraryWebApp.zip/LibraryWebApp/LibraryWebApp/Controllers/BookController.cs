﻿// Controllers/BookController.cs
using LibraryWebApp.Models;
using LibraryWebApp.Models.Database;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace LibraryWebApp.Controllers
{
    public class BookController : Controller
    {
        private readonly LibraryDbContext _context;

        public BookController(LibraryDbContext context)
        {
            _context = context;
        }


        public async Task<IActionResult> Index()
        {

            var list = await _context.Books.ToListAsync();
            return View(list);
        }


        public IActionResult Create()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]

        public async Task<IActionResult> Create([Bind("BookId,BookTitle,Author")] Book book)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Add(book);
                    await _context.SaveChangesAsync();

                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateException ex)
                {

                    ModelState.AddModelError(string.Empty, $"Error saving book. Detail: {ex.InnerException?.Message ?? ex.Message}");
                }
            }

            return View(book);
        }


        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var item = await _context.Books.FindAsync(id);

            if (item == null) return NotFound();

            return View(item);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BookId,BookTitle,Author")] Book model)
        {
            if (id != model.BookId) return BadRequest();

            if (ModelState.IsValid)
            {
                try
                {

                    _context.Update(model);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_context.Books.Any(e => e.BookId == model.BookId))
                    {
                        return NotFound();
                    }
                    throw;
                }
            }
            return View(model);
        }


        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var item = await _context.Books.FirstOrDefaultAsync(m => m.BookId == id);

            if (item == null) return NotFound();

            return View(item);
        }


        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var item = await _context.Books.FindAsync(id);

            if (item != null)
            {
                _context.Books.Remove(item);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }
    }
}
