using Microsoft.EntityFrameworkCore;
using LibraryWebApp.Models.Database;

var builder = WebApplication.CreateBuilder(args);


// 1. Get the connection string named "DefaultConnection" from appsettings.json
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

// 2. Register DbContext for Dependency Injection (DI)
builder.Services.AddDbContext<LibraryDbContext>(options =>

    options.UseSqlServer(connectionString));


builder.Services.AddControllersWithViews();

var app = builder.Build();


if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();