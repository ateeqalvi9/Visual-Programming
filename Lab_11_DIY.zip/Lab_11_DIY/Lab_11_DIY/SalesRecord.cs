﻿namespace SmartMart_Management_System
{
    public class SalesRecord
    {
        public int SaleId { get; set; }
        public int CustomerId { get; set; }

        public int ProductId { get; set; }

        public DateTime SaleDate { get; set; }

        public Customers Customer { get; set; }

        public Product Product { get; set; }
    }
}
