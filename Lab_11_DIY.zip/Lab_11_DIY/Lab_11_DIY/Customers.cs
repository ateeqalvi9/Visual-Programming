﻿namespace SmartMart_Management_System
{
    public class Customers
    {
        public int CustomerId { get; set; }
        public string Name { get; set; }
        public string City { get; set; }

        public ICollection<SalesRecord> SalesRecords { get; set; }

    }
}
