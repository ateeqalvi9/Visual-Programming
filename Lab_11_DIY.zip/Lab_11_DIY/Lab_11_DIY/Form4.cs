﻿using SmartMart_Management_System;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_11_DIY
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int t1 = Convert.ToInt32(textBox1.Text); int t2 = Convert.ToInt32(textBox2.Text); int t3 = Convert.ToInt32(textBox3.Text);

                DateTime dt = dateTimePicker1.Value;

                MartContext mart = new MartContext();
                mart.SalesRecords.Add(new SalesRecord { SaleId = t1, CustomerId = t2, ProductId = t3, SaleDate = dt });

                mart.SaveChanges();

                MessageBox.Show("Data Inserted Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message);
            }
        }
    }
}
