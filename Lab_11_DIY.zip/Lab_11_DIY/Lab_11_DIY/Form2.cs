﻿using SmartMart_Management_System;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_11_DIY
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(textBox1.Text);
                string name = textBox2.Text;
                string city = textBox3.Text;

                MartContext mart = new MartContext();
                mart.Customers.Add(new Customers
                {
                    CustomerId = id,
                    Name = name,
                    City = city
                });

                mart.SaveChanges();

                MessageBox.Show("Data Inserted Successfully",
                    "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
