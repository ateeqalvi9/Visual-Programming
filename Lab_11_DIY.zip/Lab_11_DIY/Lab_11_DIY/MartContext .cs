﻿using Microsoft.EntityFrameworkCore;

namespace SmartMart_Management_System
{
    public class MartContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            optionsBuilder.UseSqlServer("Data Source=(localdb)\\ProjectModels;Initial Catalog=SmartMartDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False");

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Customers>().HasKey(c => c.CustomerId); 
            modelBuilder.Entity<Customers>().Property(c => c.CustomerId).ValueGeneratedOnAdd();

            modelBuilder.Entity<Product>().HasKey(p => p.ProductId); 
            modelBuilder.Entity<Product>().Property(p => p.ProductId).ValueGeneratedOnAdd();

            modelBuilder.Entity<SalesRecord>().HasKey(s => s.SaleId); 
            modelBuilder.Entity<SalesRecord>().Property(s => s.SaleId).ValueGeneratedOnAdd();
        }

        public DbSet<Customers> Customers { get; set; }

        public DbSet<Product> Products { get; set; }

        public DbSet<SalesRecord> SalesRecords { get; set; }
    }
}
