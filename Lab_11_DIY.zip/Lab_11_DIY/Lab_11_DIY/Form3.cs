﻿using SmartMart_Management_System;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_11_DIY
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int t1 = Convert.ToInt32(textBox1.Text); string t2 = textBox2.Text; string t3 = textBox3.Text;

                MartContext mart = new MartContext(); mart.Products.Add(new Product { ProductId = t1, ProductName = t2, Category = t3 }); mart.SaveChanges();

                MessageBox.Show("Data Inserted Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message);
            }
        }
    }
}
