﻿using SmartMart_Management_System;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_11_DIY
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MartContext context = new MartContext();
            var result = from c in context.Customers
                         join s in context.SalesRecords on c.CustomerId equals s.CustomerId
                         join p in context.Products on s.ProductId equals p.ProductId
                         select new
                         {
                             CustomerName = c.Name,
                             c.City,
                             ProductName = p.ProductName,
                             s.SaleDate
                         };
            dataGridView1.DataSource = result.ToList();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            MartContext context = new MartContext();
            var result = from c in context.Customers
                         join s in context.SalesRecords on c.CustomerId equals s.CustomerId into cs
                         from sale in cs.DefaultIfEmpty()
                         join p in context.Products on sale.ProductId equals p.ProductId into ps
                         from product in ps.DefaultIfEmpty()
                         select new
                         {
                             CustomerName = c.Name,
                             c.City,
                             ProductName = product != null ? product.ProductName : "No Purchase"
                         };
            dataGridView1.DataSource = result.ToList();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            MartContext context = new MartContext(); var result = from c in context.Customers
                                                                  join s in context.SalesRecords on c.CustomerId equals s.CustomerId into salesGroup
                                                                  select new
                                                                  {
                                                                      CustomerName = c.Name,
                                                                      TotalPurchasedProducts = salesGroup.Count()
                                                                  };
            dataGridView1.DataSource = result.ToList();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            MartContext context = new MartContext(); var result = from p in context.Products
                                                                  join s in context.SalesRecords on p.ProductId equals s.ProductId
                                                                  group s by p.Category into g
                                                                  select new
                                                                  {
                                                                      Category = g.Key,
                                                                      TotalSales = g.Count()
                                                                  };
            dataGridView1.DataSource = result.ToList();
        }
    }
}

