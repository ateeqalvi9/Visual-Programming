﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Lab_11_DIY.Migrations
{
    /// <inheritdoc />
    public partial class MartDatabase : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
