﻿namespace SmartMart_Management_System
{
    public class Product
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string Category { get; set; }

        public ICollection<SalesRecord> SalesRecords { get; set; }
    }
}
