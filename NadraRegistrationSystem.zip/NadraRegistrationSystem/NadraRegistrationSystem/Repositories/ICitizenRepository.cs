﻿using NadraRegistrationSystem.Models;

namespace NadraRegistrationSystem.Repositories
{
    public interface ICitizenRepository
    {
        Task<Citizen> GetByCnicAsync(string cnic);
        Task<Citizen> GetByIdAsync(int id);
        Task AddCitizenAsync(Citizen citizen);
        Task UpdateCitizenAsync(Citizen citizen);
    }
}