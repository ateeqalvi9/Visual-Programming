﻿using Microsoft.EntityFrameworkCore;
using NadraRegistrationSystem.Data;
using NadraRegistrationSystem.Models;

namespace NadraRegistrationSystem.Repositories
{
    public class CitizenRepository : ICitizenRepository
    {
        private readonly ApplicationDbContext _context;

        public CitizenRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<Citizen> GetByCnicAsync(string cnic)
        {
            return await _context.Citizens.FirstOrDefaultAsync(c => c.CNIC == cnic);
        }

        public async Task<Citizen> GetByIdAsync(int id)
        {
            return await _context.Citizens.FindAsync(id);
        }

        public async Task AddCitizenAsync(Citizen citizen)
        {
            _context.Citizens.Add(citizen);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateCitizenAsync(Citizen citizen)
        {
            _context.Citizens.Update(citizen);
            await _context.SaveChangesAsync();
        }
    }
}