﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NadraRegistrationSystem.Models;
using NadraRegistrationSystem.Repositories;

namespace NadraRegistrationSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class CitizenController : ControllerBase
    {
        private readonly ICitizenRepository _repository;

        public CitizenController(ICitizenRepository repository)
        {
            _repository = repository;
        }

        [HttpGet("verify/{cnic}")]
        [Authorize(Roles = "Admin, DepartmentOfficer")]
        public async Task<IActionResult> VerifyCitizen(string cnic)
        {
            var citizen = await _repository.GetByCnicAsync(cnic);
            if (citizen == null) return NotFound("Citizen not found.");
            return Ok(citizen);
        }

        [HttpPost("register")]
        [Authorize(Roles = "Admin, DepartmentOfficer")]
        public async Task<IActionResult> RegisterCitizen([FromBody] Citizen citizen)
        {
            var existing = await _repository.GetByCnicAsync(citizen.CNIC);
            if (existing != null)
            {
                return BadRequest("CNIC already exists.");
            }

            await _repository.AddCitizenAsync(citizen);
            return Ok(new { Message = "Citizen Registered Successfully", Id = citizen.CitizenId });
        }
    }
}