﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NadraRegistrationSystem.Data;
using NadraRegistrationSystem.Models;

namespace NadraRegistrationSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AdminController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public AdminController(ApplicationDbContext context)
        {
            _context = context;
        }

        // 1. Officer submits a request (No changes made to citizen yet)
        [HttpPost("request-update")]
        [Authorize(Roles = "DepartmentOfficer")]
        public async Task<IActionResult> SubmitRequest([FromBody] CitizenUpdateRequest request)
        {
            var citizen = await _context.Citizens.FindAsync(request.CitizenId);
            if (citizen == null) return NotFound("Citizen not found");

            request.Status = "Pending";
            request.RequestedDate = DateTime.UtcNow;
            request.RequestedByUserId = User.Identity.Name;

            _context.CitizenUpdateRequests.Add(request);
            await _context.SaveChangesAsync();
            return Ok("Request submitted for approval.");
        }

        // 2. Admin views pending requests
        [HttpGet("pending-requests")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetPendingRequests()
        {
            var requests = await _context.CitizenUpdateRequests
                                         .Where(r => r.Status == "Pending")
                                         .ToListAsync();
            return Ok(requests);
        }

        // 3. Admin Approves/Rejects
        [HttpPost("process-request/{requestId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> ProcessRequest(int requestId, [FromQuery] bool approve)
        {
            var request = await _context.CitizenUpdateRequests.FindAsync(requestId);
            if (request == null) return NotFound("Request not found");

            if (approve)
            {
                var citizen = await _context.Citizens.FindAsync(request.CitizenId);
                if (citizen != null)
                {
                    // Business Rule: Map string field name to actual property
                    switch (request.RequestedField)
                    {
                        case "Address": citizen.Address = request.NewValue; break;
                        case "MaritalStatus": citizen.MaritalStatus = request.NewValue; break;
                        case "Name": citizen.FullName = request.NewValue; break;
                            // CNIC and DOB are typically immutable
                    }
                    request.Status = "Approved";
                    _context.Citizens.Update(citizen);
                }
            }
            else
            {
                request.Status = "Rejected";
            }

            await _context.SaveChangesAsync();
            return Ok($"Request {request.Status}");
        }
    }
}