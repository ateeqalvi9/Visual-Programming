﻿using System.ComponentModel.DataAnnotations;

namespace NadraRegistrationSystem.Models
{
    public class Department
    {
        [Key]
        public int DepartmentId { get; set; }
        public string DepartmentName { get; set; } // Union Council, Bank, Police
        public string DepartmentType { get; set; } // Government, Financial
        public bool IsActive { get; set; } = true;
    }
}