﻿using System.ComponentModel.DataAnnotations;

namespace NadraRegistrationSystem.Models
{
    public class Citizen
    {
        [Key]
        public int CitizenId { get; set; }

        [Required]
        public string FullName { get; set; }

        [Required]
        [StringLength(13, MinimumLength = 13, ErrorMessage = "CNIC must be 13 digits")]
        public string CNIC { get; set; }

        public string FatherName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Gender { get; set; } // Male, Female
        public string Address { get; set; }
        public string MaritalStatus { get; set; }
        public string Nationality { get; set; } = "Pakistani";
        public bool IsAlive { get; set; } = true;
        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
    }
}