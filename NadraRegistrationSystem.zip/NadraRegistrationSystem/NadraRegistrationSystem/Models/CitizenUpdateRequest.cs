﻿using System.ComponentModel.DataAnnotations;

namespace NadraRegistrationSystem.Models
{
    public class CitizenUpdateRequest
    {
        [Key]
        public int RequestId { get; set; }
        public int CitizenId { get; set; } // FK to Citizen
        public string RequestedByUserId { get; set; } // User ID of Officer
        public string RequestedField { get; set; } // e.g., "Address"
        public string OldValue { get; set; }
        public string NewValue { get; set; }
        public string Status { get; set; } = "Pending"; // Pending, Approved, Rejected
        public DateTime RequestedDate { get; set; } = DateTime.UtcNow;
    }
}