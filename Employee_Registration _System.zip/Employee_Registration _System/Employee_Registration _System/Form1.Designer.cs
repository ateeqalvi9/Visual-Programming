﻿namespace Employee_Registration__System
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtName = new TextBox();
            txtFatherName = new TextBox();
            txtCNIC = new TextBox();
            txtDesignation = new TextBox();
            txtSalary = new TextBox();
            cmbDepartment = new ComboBox();
            dtHireDate = new DateTimePicker();
            btnAdd = new Button();
            btnUpdate = new Button();
            btnDelete = new Button();
            btnLoad = new Button();
            dataGridView1 = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // txtName
            // 
            txtName.Location = new Point(28, 21);
            txtName.Name = "txtName";
            txtName.PlaceholderText = "Name";
            txtName.Size = new Size(100, 23);
            txtName.TabIndex = 1;
            // 
            // txtFatherName
            // 
            txtFatherName.Location = new Point(152, 21);
            txtFatherName.Name = "txtFatherName";
            txtFatherName.PlaceholderText = "FatherName";
            txtFatherName.Size = new Size(100, 23);
            txtFatherName.TabIndex = 2;
            // 
            // txtCNIC
            // 
            txtCNIC.Location = new Point(277, 21);
            txtCNIC.Name = "txtCNIC";
            txtCNIC.PlaceholderText = "CNIC";
            txtCNIC.Size = new Size(100, 23);
            txtCNIC.TabIndex = 3;
            // 
            // txtDesignation
            // 
            txtDesignation.Location = new Point(405, 21);
            txtDesignation.Name = "txtDesignation";
            txtDesignation.PlaceholderText = "DEsignation";
            txtDesignation.Size = new Size(100, 23);
            txtDesignation.TabIndex = 4;
            // 
            // txtSalary
            // 
            txtSalary.Location = new Point(530, 21);
            txtSalary.Name = "txtSalary";
            txtSalary.PlaceholderText = "Salary";
            txtSalary.Size = new Size(100, 23);
            txtSalary.TabIndex = 5;
            // 
            // cmbDepartment
            // 
            cmbDepartment.FormattingEnabled = true;
            cmbDepartment.Location = new Point(31, 75);
            cmbDepartment.Name = "cmbDepartment";
            cmbDepartment.Size = new Size(121, 23);
            cmbDepartment.TabIndex = 6;
            cmbDepartment.Text = "Department";
            // 
            // dtHireDate
            // 
            dtHireDate.Location = new Point(178, 75);
            dtHireDate.Name = "dtHireDate";
            dtHireDate.Size = new Size(200, 23);
            dtHireDate.TabIndex = 7;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(35, 122);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(75, 23);
            btnAdd.TabIndex = 8;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(134, 122);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(75, 23);
            btnUpdate.TabIndex = 9;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(230, 122);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(75, 23);
            btnDelete.TabIndex = 10;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnLoad
            // 
            btnLoad.Location = new Point(324, 122);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(75, 23);
            btnLoad.TabIndex = 11;
            btnLoad.Text = "Load";
            btnLoad.UseVisualStyleBackColor = true;
            btnLoad.Click += btnLoad_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(1, 162);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(801, 286);
            dataGridView1.TabIndex = 12;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dataGridView1);
            Controls.Add(btnLoad);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(dtHireDate);
            Controls.Add(cmbDepartment);
            Controls.Add(txtSalary);
            Controls.Add(txtDesignation);
            Controls.Add(txtCNIC);
            Controls.Add(txtFatherName);
            Controls.Add(txtName);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox txtName;
        private TextBox txtFatherName;
        private TextBox txtCNIC;
        private TextBox txtDesignation;
        private TextBox txtSalary;
        private ComboBox cmbDepartment;
        private DateTimePicker dtHireDate;
        private Button btnAdd;
        private Button btnUpdate;
        private Button btnDelete;
        private Button btnLoad;
        private DataGridView dataGridView1;
    }
}
