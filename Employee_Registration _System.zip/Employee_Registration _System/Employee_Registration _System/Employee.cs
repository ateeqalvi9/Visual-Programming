﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Registration__System
{
    public class Employee
    {
        public int EmpId { get; set; }  // Primary Key
        public string Name { get; set; }
        public string FatherName { get; set; }
        public string CNIC { get; set; }
        public string Designation { get; set; }
        public decimal Salary { get; set; }
        public string Department { get; set; }
        public DateTime HireDate { get; set; }
    }
}
