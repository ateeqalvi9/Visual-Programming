using EmployeeApp.Data;

namespace Employee_Registration__System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            cmbDepartment.Items.Add("HR");
            cmbDepartment.Items.Add("Accounts");
            cmbDepartment.Items.Add("IT");
            cmbDepartment.Items.Add("Sales");
            cmbDepartment.Items.Add("Marketing");
            cmbDepartment.Items.Add("Admin");

        }

        private bool ValidateForm()
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Name cannot be empty.");
                return false;
            }

            if (txtCNIC.Text.Length != 13)
            {
                MessageBox.Show("CNIC must be 13 digits.");
                return false;
            }

            if (!decimal.TryParse(txtSalary.Text, out _))
            {
                MessageBox.Show("Salary must be numeric.");
                return false;
            }

            return true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtName.Text))
                {
                    MessageBox.Show("Name cannot be empty.");
                    return;
                }
                if (txtCNIC.Text.Length != 13)
                {
                    MessageBox.Show("CNIC must be exactly 13 digits.");
                    return;
                }
                if (!decimal.TryParse(txtSalary.Text, out decimal salary))
                {
                    MessageBox.Show("Salary must be numeric.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(cmbDepartment.Text))
                {
                    MessageBox.Show("Please select a department.");
                    return;
                }
                Employee emp = new Employee
                {
                    Name = txtName.Text,
                    FatherName = txtFatherName.Text,
                    CNIC = txtCNIC.Text,
                    Designation = txtDesignation.Text,
                    Salary = salary,
                    Department = cmbDepartment.Text,
                    HireDate = dtHireDate.Value
                };
                using (var db = new EmployeeDbContext())
                {
                    db.Employees.Add(emp);
                    db.SaveChanges();
                }

                MessageBox.Show("Employee Added Successfully!");
            }
            catch (Exception ex)
            { 
                MessageBox.Show(ex.InnerException?.Message ?? ex.Message, "Insert Error");
            }
        }


        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (!ValidateForm()) return;

            Employee emp = new Employee
            {
                Name = txtName.Text,
                FatherName = txtFatherName.Text,
                CNIC = txtCNIC.Text,
                Designation = txtDesignation.Text,
                Salary = Convert.ToDecimal(txtSalary.Text),
                Department = cmbDepartment.Text,
                HireDate = dtHireDate.Value
            };

            using (var db = new EmployeeDbContext())
            {
                db.Employees.Update(emp);
                db.SaveChanges();
            }

            MessageBox.Show("Record Updated Successfully!");
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;

            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Please enter a Name to delete.");
                return;
            }

            using (var db = new EmployeeDbContext())
            {
                var emp = db.Employees.FirstOrDefault(x => x.Name == name);

                if (emp == null)
                {
                    MessageBox.Show("No employee found with this name.");
                    //return;
                }

                db.Employees.Remove(emp);
                db.SaveChanges();
            }

            MessageBox.Show("Record Deleted Successfully!");
        }


        private void btnLoad_Click(object sender, EventArgs e)
        {
            using (var db = new EmployeeDbContext())
            {
                dataGridView1.DataSource = db.Employees.ToList();
            }
        }


    }
}
